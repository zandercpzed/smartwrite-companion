import { BasePanel } from './BasePanel';
import { SuggestionsResult } from '../../types';
import SmartWriteCompanionPlugin from "../../main";

export class SuggestionsPanel extends BasePanel {
    private plugin: SmartWriteCompanionPlugin;
    private suggestions: SuggestionsResult | null = null;

    constructor(containerEl: HTMLElement, plugin: SmartWriteCompanionPlugin) {
        super(containerEl, 'Suggestions');
        this.plugin = plugin;
    }

    protected renderContent(): void {
        if (!this.plugin) return;
        this.contentEl.empty();

        if (!this.suggestions || this.suggestions.suggestions.length === 0) {
            this.contentEl.createDiv({ cls: 'smartwrite-no-suggestions' }).setText('No suggestions available');
            this.updateBadge('');
            return;
        }

        // Update badge
        this.updateBadge(this.suggestions.suggestions.length);

        const listContainer = this.contentEl.createDiv({ cls: 'smartwrite-suggestions-list' });

        // Sort suggestions? High to Low? For now, render as is.
        // Assuming data arrives sorted.
        
        for (const suggestion of this.suggestions.suggestions) {
            const item = listContainer.createDiv({ cls: 'smartwrite-suggestion-item' });

            // Dot
            const dot = item.createDiv({ cls: 'smartwrite-severity-dot' });
            // Map severity/category to visual classes
            // Image shows: 
            // - Grammar (Red)
            // - Style (Orange or Teal?)
            // - Clarity (Teal)
            // - Redundancy (Orange)
            
            // Logic based on types commonly returned:
            const typeLower = suggestion.type.toLowerCase();
            if (typeLower === 'grammar') dot.addClass('smartwrite-severity-error');
            else if (typeLower === 'redundancy' || (typeLower === 'style' && suggestion.severity === 'medium')) dot.addClass('smartwrite-severity-warning');
            else dot.addClass('smartwrite-severity-info'); // Clarity, Style (low), etc.

            // Content
            const content = item.createDiv({ cls: 'smartwrite-suggestion-content' });
            
            // Type (e.g. Grammar)
            const type = content.createDiv({ cls: 'smartwrite-suggestion-type' });
            // Capitalize first letter
            type.setText(suggestion.type.charAt(0).toUpperCase() + suggestion.type.slice(1));

            // Message / Description
            const description = content.createDiv({ cls: 'smartwrite-suggestion-description' });
            description.setText(suggestion.message);

            // Explanation (tooltip or expand? Image doesn't show it visible initially)
            // We can add it as title attribute for now
            if (suggestion.explanation) {
                item.setAttribute('title', suggestion.explanation);
            }
        }
    }

    public update(suggestions: SuggestionsResult | null): void {
        this.suggestions = suggestions;
        this.renderContent();
    }
}