import React, { useState } from 'react';
import { ChevronDown, ChevronRight } from 'lucide-react';

/**
 * COMPONENTE: TextMetrics
 *
 * Funcionalidades:
 * - Exibe métricas básicas do texto atual
 * - Contagem de caracteres (com/sem espaços)
 * - Análise estrutural: sentenças, parágrafos
 * - Cálculo de tempo de leitura estimado
 * - Contagem de palavras únicas (vocabulário)
 *
 * Interface:
 * - Layout hierárquico com indentação
 * - Formatação monospace para números
 * - Agrupamento lógico das métricas
 */
export function TextMetrics() {
  // ESTADO: Controle de expansão do painel
  const [isExpanded, setIsExpanded] = useState(true);

  // DADOS MOCKADOS: Métricas do texto sendo analisado
  const metrics = {
    characters: 6842,        // Total de caracteres
    charactersNoSpaces: 5691, // Caracteres sem espaços
    sentences: 89,           // Número de sentenças
    paragraphs: 12,          // Número de parágrafos
    readingTime: 5,          // Tempo de leitura estimado (minutos)
    uniqueWords: 412         // Palavras únicas no vocabulário
  };

  return (
    // CONTAINER DO MÓDULO: Estrutura padrão
    <div className="module">
      {/* HEADER EXPANSÍVEL */}
      <button
        className="module-header"
        onClick={() => setIsExpanded(!isExpanded)}
      >
        {isExpanded ? <ChevronDown size={14} /> : <ChevronRight size={14} />}
        <span>Text Metrics</span>
      </button>

      {/* CONTEÚDO: Lista hierárquica de métricas */}
      {isExpanded && (
        <div className="module-content">
          {/* LISTA DE MÉTRICAS: Formatação consistente */}
          <div className="metrics-list">
            {/* MÉTRICA: Caracteres totais */}
            <div className="metric-row">
              <span className="stat-label">Characters</span>
              <span className="stat-mono">{metrics.characters.toLocaleString()}</span>
            </div>

            {/* MÉTRICA: Caracteres sem espaços (indentada) */}
            <div className="metric-row metric-indent">
              <span className="stat-label">No spaces</span>
              <span className="stat-mono">{metrics.charactersNoSpaces.toLocaleString()}</span>
            </div>

            {/* MÉTRICA: Número de sentenças */}
            <div className="metric-row">
              <span className="stat-label">Sentences</span>
              <span className="stat-mono">{metrics.sentences}</span>
            </div>

            {/* MÉTRICA: Número de parágrafos */}
            <div className="metric-row">
              <span className="stat-label">Paragraphs</span>
              <span className="stat-mono">{metrics.paragraphs}</span>
            </div>

            {/* MÉTRICA: Tempo de leitura estimado */}
            <div className="metric-row">
              <span className="stat-label">Reading time</span>
              <span className="stat-mono">{metrics.readingTime} min</span>
            </div>

            {/* MÉTRICA: Vocabulário único */}
            <div className="metric-row">
              <span className="stat-label">Unique words</span>
              <span className="stat-mono">{metrics.uniqueWords}</span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
