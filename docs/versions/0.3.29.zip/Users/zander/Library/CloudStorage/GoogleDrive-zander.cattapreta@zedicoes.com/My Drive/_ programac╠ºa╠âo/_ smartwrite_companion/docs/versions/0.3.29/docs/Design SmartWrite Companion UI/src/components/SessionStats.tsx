import React, { useState } from 'react';
import { ChevronDown, ChevronRight } from 'lucide-react';

/**
 * COMPONENTE: SessionStats
 *
 * Funcionalidades:
 * - Exibe estatísticas da sessão de escrita atual
 * - Mostra progresso em relação à meta diária
 * - Calcula e exibe velocidade de escrita (WPM)
 * - Interface expansível/colapsível
 *
 * Dados mockados para demonstração:
 * - wordCount: Contagem atual de palavras
 * - goalCount: Meta diária configurada
 * - sessionTime: Tempo da sessão em minutos
 * - writingPace: Velocidade de escrita em palavras por minuto
 */
export function SessionStats() {
  // ESTADO: Controle de expansão do painel
  const [isExpanded, setIsExpanded] = useState(true);

  // DADOS MOCKADOS: Simulação de dados da sessão
  const wordCount = 1247;    // Palavras escritas na sessão
  const goalCount = 2000;    // Meta diária
  const sessionTime = 45;    // Tempo em minutos
  const writingPace = 28;    // Palavras por minuto
  const progress = (wordCount / goalCount) * 100; // Progresso percentual

  return (
    // CONTAINER DO MÓDULO: Estrutura padrão com header expansível
    <div className="module">
      {/* HEADER EXPANSÍVEL: Botão para expandir/colapsar */}
      <button
        className="module-header"
        onClick={() => setIsExpanded(!isExpanded)}
      >
        {/* ÍCONE DINÂMICO: Chevron baseado no estado */}
        {isExpanded ? <ChevronDown size={14} /> : <ChevronRight size={14} />}
        <span>Session Stats</span>
      </button>

      {/* CONTEÚDO CONDICIONAL: Só renderiza se expandido */}
      {isExpanded && (
        <div className="module-content">
          {/* MÉTRICA PRINCIPAL: Contagem de palavras em destaque */}
          <div className="stat-large">
            <div className="stat-value">{wordCount.toLocaleString()}</div>
            <div className="stat-label">words</div>
          </div>

          {/* ITEM DE ESTATÍSTICA: Meta diária com progresso */}
          <div className="stat-item">
            <div className="stat-row">
              <span className="stat-label">Today's goal</span>
              <span className="stat-mono">{wordCount.toLocaleString()} / {goalCount.toLocaleString()}</span>
            </div>
            {/* BARRA DE PROGRESSO VISUAL */}
            <div className="progress-bar">
              <div
                className="progress-fill"
                style={{ width: `${Math.min(progress, 100)}%` }}
              />
            </div>
          </div>

          {/* GRID DE ESTATÍSTICAS: Tempo e velocidade */}
          <div className="stats-grid">
            <div className="stat-item">
              <span className="stat-label">Session time</span>
              <span className="stat-mono">{sessionTime} min</span>
            </div>
            <div className="stat-item">
              <span className="stat-label">Writing pace</span>
              <span className="stat-mono">{writingPace} wpm</span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
