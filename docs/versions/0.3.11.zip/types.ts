export interface TextMetrics {
    words: string[];
    sentences: string[];
    paragraphs: string[];
    characters: number;
    charactersNoSpaces: number;
    syllables: number;
    wordFrequency: Map<string, number>;
    repetitions: Array<{ word: string; count: number }>;
}

export interface TextStats {
    wordFrequency: Map<string, number>;
    averageWordLength: number;
    averageSentenceLength: number;
    readingTime: number;
}

export interface SessionStats {
    startTime: Date;
    endTime?: Date;
    wordsWritten: number;
    timeSpent: number;
    wpm: number;
    progress: number;
}

export interface DailyProgress {
    date: string;
    wordsWritten: number;
    goal: number;
    sessions: SessionStats[];
}