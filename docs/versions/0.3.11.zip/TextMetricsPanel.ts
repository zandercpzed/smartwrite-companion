import { BasePanel } from './BasePanel';
import { TextMetrics } from './types';
import { StatsEngine } from './StatsEngine';

export class TextMetricsPanel extends BasePanel {
    private metrics: TextMetrics | null = null;
    private statsEngine: StatsEngine;

    constructor(containerEl: HTMLElement) {
        super(containerEl, 'Text Metrics');
        this.statsEngine = new StatsEngine();
    }

    protected renderContent(): void {
        this.contentEl.empty();

        if (!this.metrics) {
            this.contentEl.setText('No text to analyze');
            return;
        }

        // LISTA DE MÉTRICAS: Formatação consistente
        const metricsList = this.contentEl.createDiv({ cls: 'metrics-list' });

        // MÉTRICA: Caracteres totais
        const charsRow = metricsList.createDiv({ cls: 'metric-row' });
        charsRow.createSpan({ cls: 'stat-label' }).setText('Characters');
        charsRow.createSpan({ cls: 'stat-mono' }).setText(this.metrics.characters.toLocaleString());

        // MÉTRICA: Caracteres sem espaços (indentada)
        const charsNoSpacesRow = metricsList.createDiv({ cls: 'metric-row metric-indent' });
        charsNoSpacesRow.createSpan({ cls: 'stat-label' }).setText('No spaces');
        charsNoSpacesRow.createSpan({ cls: 'stat-mono' }).setText(this.metrics.charactersNoSpaces.toLocaleString());

        // MÉTRICA: Número de sentenças
        const sentencesRow = metricsList.createDiv({ cls: 'metric-row' });
        sentencesRow.createSpan({ cls: 'stat-label' }).setText('Sentences');
        sentencesRow.createSpan({ cls: 'stat-mono' }).setText(this.metrics.sentences.length.toString());

        // MÉTRICA: Número de parágrafos
        const paragraphsRow = metricsList.createDiv({ cls: 'metric-row' });
        paragraphsRow.createSpan({ cls: 'stat-label' }).setText('Paragraphs');
        paragraphsRow.createSpan({ cls: 'stat-mono' }).setText(this.metrics.paragraphs.length.toString());

        // MÉTRICA: Tempo de leitura estimado
        const readingRow = metricsList.createDiv({ cls: 'metric-row' });
        readingRow.createSpan({ cls: 'stat-label' }).setText('Reading time');
        readingRow.createSpan({ cls: 'stat-mono' }).setText(`${Math.ceil(this.metrics.words.length / 200)} min`);

        // MÉTRICA: Vocabulário único
        const uniqueRow = metricsList.createDiv({ cls: 'metric-row' });
        uniqueRow.createSpan({ cls: 'stat-label' }).setText('Unique words');
        uniqueRow.createSpan({ cls: 'stat-mono' }).setText(this.metrics.wordFrequency.size.toString());
    }

    public updateContent(metrics: TextMetrics): void {
        this.metrics = metrics;
        this.renderContent();
    }
}