import { BasePanel } from './BasePanel';

export class ReadabilityPanel extends BasePanel {
    constructor(containerEl: HTMLElement) {
        super(containerEl, 'Readability');
    }

    protected renderContent(): void {
        this.contentEl.empty();
        this.contentEl.setText('Readability analysis coming soon...');
    }
}