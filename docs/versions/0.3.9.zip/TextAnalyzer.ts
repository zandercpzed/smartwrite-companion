import { TextMetrics, TextStats } from './types';

export class TextAnalyzer {
    analyze(text: string): TextMetrics & TextStats {
        const metrics = this.calculateMetrics(text);
        const stats = this.calculateStats(text, metrics);

        return { ...metrics, ...stats };
    }

    private calculateMetrics(text: string): TextMetrics {
        const characters = text.length;
        const words = this.countWords(text);
        const sentences = this.countSentences(text);
        const paragraphs = this.countParagraphs(text);
        const syllables = this.countSyllables(text);

        return {
            characters,
            words,
            sentences,
            paragraphs,
            syllables,
        };
    }

    private calculateStats(text: string, metrics: TextMetrics): TextStats {
        const wordFrequency = this.calculateWordFrequency(text);
        const averageWordLength = metrics.characters / Math.max(metrics.words, 1);
        const averageSentenceLength = metrics.words / Math.max(metrics.sentences, 1);
        const readingTime = metrics.words / 200; // Assuming 200 WPM

        return {
            wordFrequency,
            averageWordLength,
            averageSentenceLength,
            readingTime,
        };
    }

    private countWords(text: string): number {
        return text.trim().split(/\s+/).filter(word => word.length > 0).length;
    }

    private countSentences(text: string): number {
        // Simple regex for sentence endings
        const sentences = text.split(/[.!?]+/).filter(s => s.trim().length > 0);
        return Math.max(sentences.length, 1);
    }

    private countParagraphs(text: string): number {
        const paragraphs = text.split(/\n\s*\n/).filter(p => p.trim().length > 0);
        return Math.max(paragraphs.length, 1);
    }

    private countSyllables(text: string): number {
        // Simple vowel-based estimation
        const words = text.toLowerCase().split(/\s+/);
        let totalSyllables = 0;

        for (const word of words) {
            if (word.length === 0) continue;

            let syllables = 0;
            let previousWasVowel = false;

            for (const char of word) {
                const isVowel = 'aeiouy'.includes(char);
                if (isVowel && !previousWasVowel) {
                    syllables++;
                }
                previousWasVowel = isVowel;
            }

            // Ensure at least 1 syllable per word
            totalSyllables += Math.max(syllables, 1);
        }

        return totalSyllables;
    }

    private calculateWordFrequency(text: string): Map<string, number> {
        const frequency = new Map<string, number>();
        const words = text.toLowerCase()
            .replace(/[^\w\s]/g, '')
            .split(/\s+/)
            .filter(word => word.length > 0);

        for (const word of words) {
            frequency.set(word, (frequency.get(word) || 0) + 1);
        }

        return frequency;
    }
}