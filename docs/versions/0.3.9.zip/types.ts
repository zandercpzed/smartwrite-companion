export interface TextMetrics {
    characters: number;
    words: number;
    sentences: number;
    paragraphs: number;
    syllables: number;
}

export interface TextStats {
    wordFrequency: Map<string, number>;
    averageWordLength: number;
    averageSentenceLength: number;
    readingTime: number;
}

export interface SessionStats {
    startTime: Date;
    endTime?: Date;
    wordsWritten: number;
    timeSpent: number;
    wpm: number;
    progress: number;
}

export interface DailyProgress {
    date: string;
    wordsWritten: number;
    goal: number;
    sessions: SessionStats[];
}