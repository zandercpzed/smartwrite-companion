import { ItemView, WorkspaceLeaf } from 'obsidian';
import SmartWriteCompanionPlugin from './main';
import { BasePanel } from './BasePanel';
import { SessionStatsPanel } from './SessionStatsPanel';
import { TextMetricsPanel } from './TextMetricsPanel';
import { ReadabilityPanel } from './ReadabilityPanel';
import { SuggestionsPanel } from './SuggestionsPanel';
import { PersonaPanel } from './PersonaPanel';
import { TextAnalyzer } from './TextAnalyzer';

export class SidebarView extends ItemView {
    private plugin: SmartWriteCompanionPlugin;
    private panels: BasePanel[] = [];
    private textAnalyzer: TextAnalyzer;
    private settingsPanel: HTMLElement | null = null;
    private moduleStates: { [key: string]: boolean } = {
        sessionStats: true,
        textMetrics: true,
        readability: false,
        suggestions: false,
        personaAnalysis: false
    };

    constructor(leaf: WorkspaceLeaf, plugin: SmartWriteCompanionPlugin) {
        super(leaf);
        this.plugin = plugin;
        this.textAnalyzer = new TextAnalyzer();
    }

    getViewType(): string {
        return 'smartwrite-sidebar';
    }

    getDisplayText(): string {
        return 'SmartWrite Companion';
    }

    async onOpen(): Promise<void> {
        const container = this.containerEl.children[1];
        container.empty();
        container.addClass('smartwrite-sidebar');

        // Create header
        this.createHeader(container);

        // Create settings panel (initially hidden)
        this.createSettingsPanel(container);

        // Create panels container
        const panelsContainer = container.createDiv({ cls: 'smartwrite-panels-container' });
        this.createPanels(panelsContainer);
    }

    private createHeader(container: Element): void {
        const header = container.createDiv({ cls: 'smartwrite-header' });

        // Title
        const title = header.createDiv({ cls: 'smartwrite-title' });
        title.setText('SmartWrite Companion');

        // Settings button
        const settingsBtn = header.createDiv({ cls: 'smartwrite-settings-btn' });
        settingsBtn.setText('⚙');
        settingsBtn.addEventListener('click', () => this.toggleSettings());
    }

    private createSettingsPanel(container: Element): void {
        this.settingsPanel = container.createDiv({ cls: 'smartwrite-settings-panel' });
        this.settingsPanel.style.display = 'none';

        const title = this.settingsPanel.createDiv({ cls: 'settings-title' });
        title.setText('Module Visibility');

        // Session Stats toggle
        this.createModuleToggle('sessionStats', 'Session Stats');

        // Text Metrics toggle
        this.createModuleToggle('textMetrics', 'Text Metrics');

        // Readability toggle
        this.createModuleToggle('readability', 'Readability');

        // Suggestions toggle
        this.createModuleToggle('suggestions', 'Suggestions');

        // Persona Analysis toggle
        this.createModuleToggle('personaAnalysis', 'Persona Analysis');
    }

    private createModuleToggle(moduleKey: string, label: string): void {
        if (!this.settingsPanel) return;

        const toggleContainer = this.settingsPanel.createDiv({ cls: 'module-toggle' });

        const checkbox = toggleContainer.createEl('input', {
            type: 'checkbox',
            cls: 'module-checkbox'
        });
        checkbox.checked = this.moduleStates[moduleKey];
        checkbox.addEventListener('change', (e) => {
            const target = e.target as HTMLInputElement;
            this.moduleStates[moduleKey] = target.checked;
            this.updatePanelsVisibility();
        });

        const labelEl = toggleContainer.createDiv({ cls: 'module-label' });
        labelEl.setText(label);
    }

    private toggleSettings(): void {
        if (!this.settingsPanel) return;

        const isVisible = this.settingsPanel.style.display !== 'none';
        this.settingsPanel.style.display = isVisible ? 'none' : 'block';
    }

    private updatePanelsVisibility(): void {
        // This will be called when toggles change
        // For now, we'll recreate the panels when visibility changes
        const container = this.containerEl.children[1];
        const panelsContainer = container.querySelector('.smartwrite-panels-container') as HTMLElement;
        if (panelsContainer) {
            panelsContainer.empty();
            this.panels = [];
            this.createPanels(panelsContainer);
        }
    }

    private createPanels(container: Element): void {
        // Session Stats Panel
        if (this.moduleStates.sessionStats) {
            const sessionContainer = container.createDiv();
            const sessionPanel = new SessionStatsPanel(sessionContainer as HTMLElement);
            this.panels.push(sessionPanel);
        }

        // Text Metrics Panel
        if (this.moduleStates.textMetrics) {
            const metricsContainer = container.createDiv();
            const metricsPanel = new TextMetricsPanel(metricsContainer as HTMLElement);
            this.panels.push(metricsPanel);
        }

        // Readability Panel
        if (this.moduleStates.readability) {
            const readabilityContainer = container.createDiv();
            const readabilityPanel = new ReadabilityPanel(readabilityContainer as HTMLElement);
            this.panels.push(readabilityPanel);
        }

        // Suggestions Panel
        if (this.moduleStates.suggestions) {
            const suggestionsContainer = container.createDiv();
            const suggestionsPanel = new SuggestionsPanel(suggestionsContainer as HTMLElement);
            this.panels.push(suggestionsPanel);
        }

        // Persona Panel
        if (this.moduleStates.personaAnalysis) {
            const personaContainer = container.createDiv();
            const personaPanel = new PersonaPanel(personaContainer as HTMLElement);
            this.panels.push(personaPanel);
        }
    }

    public updateContent(content: string): void {
        const analysis = this.textAnalyzer.analyze(content);

        // Update session stats
        const sessionStats = this.plugin.sessionTracker.getCurrentSession();
        if (sessionStats) {
            this.plugin.sessionTracker.updateWords(analysis.words);
            const updatedSession = this.plugin.sessionTracker.getCurrentSession();
            if (updatedSession) {
                const sessionPanel = this.panels.find(p => p instanceof SessionStatsPanel) as SessionStatsPanel;
                if (sessionPanel) {
                    sessionPanel.updateContent(updatedSession);
                }
            }
        }

        // Update text metrics
        const metricsPanel = this.panels.find(p => p instanceof TextMetricsPanel) as TextMetricsPanel;
        if (metricsPanel) {
            metricsPanel.updateContent(analysis);
        }
    }

    async onClose(): Promise<void> {
        this.panels.forEach(panel => panel.unload());
        this.panels = [];
    }
}