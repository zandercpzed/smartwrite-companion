import { BasePanel } from './BasePanel';
import { TextMetrics, TextStats } from './types';
import { StatsEngine } from './StatsEngine';

export class TextMetricsPanel extends BasePanel {
    private metrics: (TextMetrics & TextStats) | null = null;
    private statsEngine: StatsEngine;

    constructor(containerEl: HTMLElement) {
        super(containerEl, 'Text Metrics');
        this.statsEngine = new StatsEngine();
    }

    protected renderContent(): void {
        this.contentEl.empty();

        if (!this.metrics) {
            this.contentEl.setText('No text to analyze');
            return;
        }

        const metricsDiv = this.contentEl.createDiv({ cls: 'text-metrics' });

        // Characters
        const charsDiv = metricsDiv.createDiv({ cls: 'metric-item' });
        charsDiv.createSpan({ cls: 'metric-label' }).setText('Characters:');
        charsDiv.createSpan({ cls: 'metric-value' }).setText(this.statsEngine.formatNumber(this.metrics.characters));

        // Words
        const wordsDiv = metricsDiv.createDiv({ cls: 'metric-item' });
        wordsDiv.createSpan({ cls: 'metric-label' }).setText('Words:');
        wordsDiv.createSpan({ cls: 'metric-value' }).setText(this.statsEngine.formatNumber(this.metrics.words));

        // Sentences
        const sentencesDiv = metricsDiv.createDiv({ cls: 'metric-item' });
        sentencesDiv.createSpan({ cls: 'metric-label' }).setText('Sentences:');
        sentencesDiv.createSpan({ cls: 'metric-value' }).setText(this.metrics.sentences.toString());

        // Paragraphs
        const paragraphsDiv = metricsDiv.createDiv({ cls: 'metric-item' });
        paragraphsDiv.createSpan({ cls: 'metric-label' }).setText('Paragraphs:');
        paragraphsDiv.createSpan({ cls: 'metric-value' }).setText(this.metrics.paragraphs.toString());

        // Reading time
        const readingDiv = metricsDiv.createDiv({ cls: 'metric-item' });
        readingDiv.createSpan({ cls: 'metric-label' }).setText('Reading Time:');
        readingDiv.createSpan({ cls: 'metric-value' }).setText(this.statsEngine.formatTime(this.metrics.readingTime));
    }

    public updateContent(metrics: TextMetrics & TextStats): void {
        this.metrics = metrics;
        this.renderContent();
    }
}