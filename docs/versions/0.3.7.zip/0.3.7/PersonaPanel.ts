import { BasePanel } from './BasePanel';

export class PersonaPanel extends BasePanel {
    constructor(containerEl: HTMLElement) {
        super(containerEl, 'Persona Analysis');
    }

    protected renderContent(): void {
        this.contentEl.empty();
        this.contentEl.setText('Persona analysis coming soon...');
    }
}