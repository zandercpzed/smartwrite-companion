import { TextMetrics, SessionStats } from '../../types';

export class StatsEngine {
    calculateReadingTime(words: number, wpm: number = 200): number {
        return words / wpm;
    }

    calculateWPM(words: number, minutes: number): number {
        return minutes > 0 ? words / minutes : 0;
    }

    calculateProgress(current: number, goal: number): number {
        return goal > 0 ? Math.min((current / goal) * 100, 100) : 0;
    }

    formatTime(minutes: number): string {
        const hours = Math.floor(minutes / 60);
        const mins = Math.floor(minutes % 60);
        const secs = Math.floor((minutes % 1) * 60);

        if (hours > 0) {
            return `${hours}h ${mins}m`;
        } else if (mins > 0) {
            return `${mins}m ${secs}s`;
        } else {
            return `${secs}s`;
        }
    }

    formatNumber(num: number): string {
        if (num >= 1000000) {
            return (num / 1000000).toFixed(1) + 'M';
        } else if (num >= 1000) {
            return (num / 1000).toFixed(1) + 'K';
        }
        return num.toString();
    }

    getTopWords(frequency: Map<string, number>, limit: number = 10): Array<[string, number]> {
        return Array.from(frequency.entries())
            .sort((a, b) => b[1] - a[1])
            .slice(0, limit);
    }
}