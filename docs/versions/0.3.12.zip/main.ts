import { Plugin, TFile, WorkspaceLeaf, debounce, MarkdownView } from 'obsidian';
import { SmartWriteSettings, DEFAULT_SETTINGS } from './settings';
import { SmartWriteSettingTab } from './settings';
import { SidebarView } from './SidebarView';
import { SessionTracker } from './src/core/SessionTracker';

export default class SmartWriteCompanionPlugin extends Plugin {
    settings: SmartWriteSettings;
    sessionTracker: SessionTracker;

    async onload() {
        await this.loadSettings();

        // Initialize session tracker
        this.sessionTracker = new SessionTracker(this);

        // Register sidebar view
        this.registerView(
            'smartwrite-sidebar',
            (leaf) => new SidebarView(leaf, this)
        );

        // Add settings tab
        this.addSettingTab(new SmartWriteSettingTab(this.app, this));

        // Add ribbon icon
        this.addRibbonIcon('lightbulb', 'SmartWrite Companion', () => {
            this.toggleSidebar();
        });

        // Add command to toggle sidebar
        this.addCommand({
            id: 'toggle-smartwrite-sidebar',
            name: 'Toggle SmartWrite Sidebar',
            callback: () => {
                this.toggleSidebar();
            }
        });

        // Register editor change event with debouncing
        this.registerDomEvent(
            document,
            'input',
            debounce(this.handleEditorChange.bind(this), 500)
        );

        // Register file open event
        this.registerEvent(
            this.app.workspace.on('file-open', (file) => {
                if (file) {
                    this.sessionTracker.startSession();
                }
            })
        );
    }

    onunload() {
        this.sessionTracker.endSession();
    }

    async loadSettings() {
        this.settings = Object.assign({}, DEFAULT_SETTINGS, await this.loadData());
    }

    async saveSettings() {
        await this.saveData(this.settings);
    }

    async activateView() {
        const { workspace } = this.app;

        let leaf: WorkspaceLeaf | null = null;
        const leaves = workspace.getLeavesOfType('smartwrite-sidebar');

        if (leaves.length > 0) {
            leaf = leaves[0];
        } else {
            leaf = workspace.getRightLeaf(false);
            if (leaf) {
                await leaf.setViewState({
                    type: 'smartwrite-sidebar',
                    active: true,
                });
            }
        }

        if (leaf) {
            workspace.revealLeaf(leaf);
        }
    }

    private toggleSidebar(): void {
        const leaves = this.app.workspace.getLeavesOfType('smartwrite-sidebar');
        if (leaves.length > 0) {
            this.app.workspace.detachLeavesOfType('smartwrite-sidebar');
        } else {
            this.activateView();
        }
    }

    private handleEditorChange(event: Event) {
        const target = event.target as HTMLElement;
        if (target.matches('.cm-editor .cm-content') ||
            target.closest('.markdown-preview-view')) {
            const activeFile = this.app.workspace.getActiveFile();
            if (activeFile && activeFile.extension === 'md') {
                const content = this.getCurrentEditorContent();
                if (content) {
                    this.updateSidebarWithContent(content);
                }
            }
        }
    }

    private getCurrentEditorContent(): string | null {
        const activeView = this.app.workspace.getActiveViewOfType(MarkdownView);
        if (activeView) {
            const editor = activeView.editor;
            return editor ? editor.getValue() : null;
        }
        return null;
    }

    private updateSidebarWithContent(content: string) {
        const leaves = this.app.workspace.getLeavesOfType('smartwrite-sidebar');
        leaves.forEach(leaf => {
            const view = leaf.view as SidebarView;
            if (view) {
                view.updateContent(content);
            }
        });
    }
}