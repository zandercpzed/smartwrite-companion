import { BasePanel } from './BasePanel';
import { SuggestionsResult } from '../../types';
import SmartWriteCompanionPlugin from "../../main";

export class SuggestionsPanel extends BasePanel {
    private plugin: SmartWriteCompanionPlugin;
    private suggestions: SuggestionsResult | null = null;

    constructor(containerEl: HTMLElement, plugin: SmartWriteCompanionPlugin) {
        super(containerEl, 'Suggestions');
        this.plugin = plugin;
    }

    protected renderContent(): void {
        if (!this.plugin) return;
        this.contentEl.empty();

        if (!this.suggestions || this.suggestions.suggestions.length === 0) {
            this.contentEl.setText('No suggestions available');
            return;
        }

        // Summary
        const summaryDiv = this.contentEl.createDiv({ cls: 'suggestions-summary' });
        summaryDiv.createSpan({ cls: 'summary-text' }).setText(`${this.suggestions.summary.total} suggestions found`);

        // Group suggestions by severity
        const groupedSuggestions = this.groupSuggestionsBySeverity();

        for (const [severity, suggestions] of Object.entries(groupedSuggestions)) {
            if (suggestions.length === 0) continue;

            const severityDiv = this.contentEl.createDiv({ cls: `suggestions-group severity-${severity}` });
            severityDiv.createEl('h4').setText(`${severity.charAt(0).toUpperCase() + severity.slice(1)} (${suggestions.length})`);

            for (const suggestion of suggestions.slice(0, 5)) { // Show max 5 per severity
                const suggestionDiv = severityDiv.createDiv({ cls: 'suggestion-item' });
                suggestionDiv.createSpan({ cls: 'suggestion-type' }).setText(`[${suggestion.type}]`);
                suggestionDiv.createSpan({ cls: 'suggestion-message' }).setText(suggestion.message);

                if (suggestion.explanation) {
                    const explanationDiv = suggestionDiv.createDiv({ cls: 'suggestion-explanation' });
                    explanationDiv.setText(suggestion.explanation);
                }
            }

            if (suggestions.length > 5) {
                severityDiv.createDiv({ cls: 'suggestion-more' }).setText(`... and ${suggestions.length - 5} more`);
            }
        }
    }

    private groupSuggestionsBySeverity(): Record<string, any[]> {
        const groups: Record<string, any[]> = {
            high: [],
            medium: [],
            low: []
        };

        if (!this.suggestions) return groups;

        for (const suggestion of this.suggestions.suggestions) {
            groups[suggestion.severity].push(suggestion);
        }

        return groups;
    }

    public update(suggestions: SuggestionsResult | null): void {
        this.suggestions = suggestions;
        this.renderContent();
    }
}