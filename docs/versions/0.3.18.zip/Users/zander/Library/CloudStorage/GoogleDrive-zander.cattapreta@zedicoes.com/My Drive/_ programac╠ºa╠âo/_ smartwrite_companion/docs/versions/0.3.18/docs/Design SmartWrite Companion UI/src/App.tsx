import React, { useState } from 'react';
import { SessionStats } from './components/SessionStats';
import { TextMetrics } from './components/TextMetrics';
import { Readability } from './components/Readability';
import { Suggestions } from './components/Suggestions';
import { PersonaAnalysis } from './components/PersonaAnalysis';
import { Settings } from 'lucide-react';

/**
 * COMPONENTE PRINCIPAL - SmartWrite Companion App
 *
 * Funcionalidades principais:
 * - Gerenciamento de estado global dos módulos
 * - Controle de visibilidade dos painéis
 * - Interface de configurações do usuário
 * - Container responsivo para os 5 módulos principais
 */
export default function App() {
  // ESTADO GLOBAL: Controle de visibilidade dos módulos
  // Permite ao usuário ativar/desativar cada painel individualmente
  const [moduleStates, setModuleStates] = useState({
    sessionStats: true,      // Estatísticas da sessão de escrita
    textMetrics: true,       // Métricas básicas do texto
    readability: true,       // Análise de legibilidade
    suggestions: true,       // Sugestões de melhoria
    personaAnalysis: true,   // Análise baseada em persona
  });

  // ESTADO: Controle do painel de configurações
  const [showSettings, setShowSettings] = useState(false);

  /**
   * HANDLER: Toggle de visibilidade dos módulos
   * Atualiza o estado para mostrar/ocultar módulos específicos
   */
  const toggleModule = (module: keyof typeof moduleStates) => {
    setModuleStates(prev => ({
      ...prev,
      [module]: !prev[module]
    }));
  };

  return (
    // CONTAINER PRINCIPAL: Sidebar do Obsidian
    // Largura fixa de 320px, altura total da viewport
    <div className="obsidian-sidebar">
      {/* HEADER: Título e botão de configurações */}
      <div className="sidebar-header">
        <h2>SmartWrite Companion</h2>
        <button
          className="settings-btn"
          onClick={() => setShowSettings(!showSettings)}
          aria-label="Settings"
        >
          <Settings size={16} />
        </button>
      </div>

      {/* PAINEL DE CONFIGURAÇÕES: Toggle switches para módulos */}
      {showSettings && (
        <div className="settings-panel">
          <h3>Module Visibility</h3>
          {/* CONTROLES DE VISIBILIDADE */}
          <label>
            <input
              type="checkbox"
              checked={moduleStates.sessionStats}
              onChange={() => toggleModule('sessionStats')}
            />
            <span>Session Stats</span>
          </label>
          <label>
            <input 
              type="checkbox" 
              checked={moduleStates.textMetrics}
              onChange={() => toggleModule('textMetrics')}
            />
            <span>Text Metrics</span>
          </label>
          <label>
            <input 
              type="checkbox" 
              checked={moduleStates.readability}
              onChange={() => toggleModule('readability')}
            />
            <span>Readability</span>
          </label>
          <label>
            <input 
              type="checkbox" 
              checked={moduleStates.suggestions}
              onChange={() => toggleModule('suggestions')}
            />
            <span>Suggestions</span>
          </label>
          <label>
            <input 
              type="checkbox" 
              checked={moduleStates.personaAnalysis}
              onChange={() => toggleModule('personaAnalysis')}
            />
            <span>Persona Analysis</span>
          </label>
        </div>
      )}

      {/* CONTAINER DOS MÓDULOS: Renderização condicional baseada no estado */}
      <div className="modules-container">
        {/* MÓDULO 1: Estatísticas da Sessão */}
        {moduleStates.sessionStats && <SessionStats />}

        {/* MÓDULO 2: Métricas do Texto */}
        {moduleStates.textMetrics && <TextMetrics />}

        {/* MÓDULO 3: Análise de Legibilidade */}
        {moduleStates.readability && <Readability />}

        {/* MÓDULO 4: Sugestões de Melhoria */}
        {moduleStates.suggestions && <Suggestions />}

        {/* MÓDULO 5: Análise de Persona (LLM) */}
        {moduleStates.personaAnalysis && <PersonaAnalysis />}
      </div>
    </div>
  );
}
