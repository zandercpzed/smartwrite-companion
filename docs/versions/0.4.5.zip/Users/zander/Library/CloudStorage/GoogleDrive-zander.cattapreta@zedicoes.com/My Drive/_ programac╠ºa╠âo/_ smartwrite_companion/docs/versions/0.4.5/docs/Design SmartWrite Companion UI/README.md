
  # Design SmartWrite Companion UI

  This is a code bundle for Design SmartWrite Companion UI. The original project is available at https://www.figma.com/design/1RQRuR8mgDT2PODDzE9ohI/Design-SmartWrite-Companion-UI.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  