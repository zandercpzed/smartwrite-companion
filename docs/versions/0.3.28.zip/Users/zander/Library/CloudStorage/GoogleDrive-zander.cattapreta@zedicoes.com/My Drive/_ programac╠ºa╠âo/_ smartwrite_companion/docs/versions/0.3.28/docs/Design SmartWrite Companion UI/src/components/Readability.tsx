import React, { useState } from 'react';
import { ChevronDown, ChevronRight } from 'lucide-react';

/**
 * COMPONENTE: Readability
 *
 * Funcionalidades:
 * - Análise de legibilidade com múltiplas fórmulas
 * - Interface para seleção de fórmula de cálculo
 * - Exibição visual da pontuação com barra de progresso
 * - Métricas secundárias específicas de cada fórmula
 *
 * Fórmulas implementadas:
 * - Flesch Reading Ease: Facilidade de leitura (0-100)
 * - Flesch-Kincaid Grade: Nível escolar equivalente
 * - Gunning Fog Index: Complexidade baseada em sentenças
 */
export function Readability() {
  // ESTADO: Controle de expansão do painel
  const [isExpanded, setIsExpanded] = useState(true);

  // ESTADO: Fórmula selecionada pelo usuário
  const [selectedFormula, setSelectedFormula] = useState('flesch-reading');

  // DADOS MOCKADOS: Resultados das análises de legibilidade
  // Estrutura: fórmula -> {score, label, secondaryScores[]}
  const readabilityData = {
    'flesch-reading': {
      score: 72,           // Pontuação 0-100
      label: 'Easy',       // Interpretação da pontuação
      secondaryScores: [   // Métricas auxiliares
        { name: 'Grade level', value: '7th grade' },
        { name: 'Avg sentence length', value: '14 words' },
        { name: 'Avg syllables/word', value: '1.4' }
      ]
    },
    'flesch-kincaid': {
      score: 6.8,          // Nível escolar
      label: 'Grade 7',    // Interpretação
      secondaryScores: [
        { name: 'Avg sentence length', value: '14 words' },
        { name: 'Avg syllables/word', value: '1.4' }
      ]
    },
    'gunning-fog': {
      score: 8.2,          // Índice de complexidade
      label: 'Grade 8',    // Interpretação
      secondaryScores: [
        { name: 'Complex words', value: '12%' },
        { name: 'Avg sentence length', value: '14 words' }
      ]
    }
  };

  // DADOS ATUAIS: Baseados na fórmula selecionada
  const currentData = readabilityData[selectedFormula as keyof typeof readabilityData];

  return (
    // CONTAINER DO MÓDULO
    <div className="module">
      {/* HEADER EXPANSÍVEL */}
      <button
        className="module-header"
        onClick={() => setIsExpanded(!isExpanded)}
      >
        {isExpanded ? <ChevronDown size={14} /> : <ChevronRight size={14} />}
        <span>Readability</span>
      </button>

      {/* CONTEÚDO: Interface de análise de legibilidade */}
      {isExpanded && (
        <div className="module-content">
          {/* SEÇÃO PRINCIPAL: Pontuação e barra visual */}
          <div className="readability-primary">
            {/* PONTUAÇÃO PRINCIPAL: Valor e interpretação */}
            <div className="readability-score">
              <span className="score-value">{currentData.score}</span>
              <span className="score-label">{currentData.label}</span>
            </div>

            {/* BARRA VISUAL: Indicador de posição na escala */}
            <div className="readability-bar">
              <div
                className="readability-indicator"
                style={{ left: `${Math.min(currentData.score, 100)}%` }}
              />
            </div>
          </div>

          {/* SELETOR DE FÓRMULA: Dropdown para escolher método */}
          <div className="formula-selector">
            <select
              value={selectedFormula}
              onChange={(e) => setSelectedFormula(e.target.value)}
              className="formula-dropdown"
            >
              <option value="flesch-reading">Flesch Reading Ease</option>
              <option value="flesch-kincaid">Flesch-Kincaid Grade</option>
              <option value="gunning-fog">Gunning Fog Index</option>
            </select>
          </div>

          {/* MÉTRICAS SECUNDÁRIAS: Dados específicos da fórmula */}
          <div className="secondary-scores">
            {currentData.secondaryScores.map((item, index) => (
              <div key={index} className="metric-row">
                <span className="stat-label">{item.name}</span>
                <span className="stat-mono">{item.value}</span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
