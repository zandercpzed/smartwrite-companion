import { BasePanel } from './BasePanel';
import { SuggestionsResult } from '../../types';
import SmartWriteCompanionPlugin from "../../main";

export class SuggestionsPanel extends BasePanel {
    private plugin: SmartWriteCompanionPlugin;
    private suggestions: SuggestionsResult | null = null;

    constructor(containerEl: HTMLElement, plugin: SmartWriteCompanionPlugin) {
        super(containerEl, 'Suggestions');
        this.plugin = plugin;
    }

    protected renderContent(): void {
        if (!this.plugin) return;
        this.contentEl.empty();

        if (!this.suggestions || this.suggestions.suggestions.length === 0) {
            this.contentEl.createDiv({ cls: 'smartwrite-no-suggestions' }).setText('No suggestions available');
            this.updateBadge('');
            return;
        }

        // Update badge
        this.updateBadge(this.suggestions.suggestions.length);

        const listContainer = this.contentEl.createDiv({ cls: 'smartwrite-suggestions-list' });

        for (const suggestion of this.suggestions.suggestions) {
            const item = listContainer.createDiv({ cls: 'smartwrite-suggestion-item' });

            // Dot
            const dot = item.createDiv({ cls: 'smartwrite-severity-dot' });
            
            // Map severity/category to visual classes
            const typeLower = suggestion.type.toLowerCase();
            if (typeLower === 'grammar') dot.addClass('smartwrite-severity-error');
            else if (typeLower === 'redundancy' || (typeLower === 'style' && suggestion.severity === 'medium')) dot.addClass('smartwrite-severity-warning');
            else dot.addClass('smartwrite-severity-info');

            // Content
            const content = item.createDiv({ cls: 'smartwrite-suggestion-content' });
            
            // Type
            const type = content.createDiv({ cls: 'smartwrite-suggestion-type' });
            type.setText(suggestion.type.charAt(0).toUpperCase() + suggestion.type.slice(1));

            // Message
            const description = content.createDiv({ cls: 'smartwrite-suggestion-description' });
            description.setText(suggestion.message);

            if (suggestion.explanation) {
                item.setAttribute('title', suggestion.explanation);
            }
        }
    }

    public update(suggestions: SuggestionsResult | null): void {
        this.suggestions = suggestions;
        this.renderContent();
    }
}