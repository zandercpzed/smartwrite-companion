import { BasePanel } from './BasePanel';
import { ReadabilityScores } from '../../types';
import SmartWriteCompanionPlugin from "../../main";

export class ReadabilityPanel extends BasePanel {
    private plugin: SmartWriteCompanionPlugin;
    private scores: ReadabilityScores | null = null;

    constructor(containerEl: HTMLElement, plugin: SmartWriteCompanionPlugin) {
        super(containerEl, 'Readability');
        this.plugin = plugin;
    }

    protected renderContent(): void {
        if (!this.plugin) return;
        this.contentEl.empty();

        if (!this.scores) {
            this.contentEl.setText('No readability data available');
            return;
        }

        const scoresDiv = this.contentEl.createDiv({ cls: 'readability-scores' });

        // Overall level
        const levelDiv = scoresDiv.createDiv({ cls: 'readability-level' });
        levelDiv.createEl('h4').setText('Overall Level');
        levelDiv.createSpan({ cls: `level-badge level-${this.scores.overallLevel}` }).setText(this.scores.overallLevel.replace('-', ' ').toUpperCase());

        // Interpretation
        const interpretationDiv = scoresDiv.createDiv({ cls: 'readability-interpretation' });
        interpretationDiv.setText(this.scores.interpretation);

        // Scores table
        const tableDiv = scoresDiv.createDiv({ cls: 'readability-table' });

        this.addScoreRow(tableDiv, 'Flesch Reading Ease', this.scores.fleschReadingEase.toFixed(1));
        this.addScoreRow(tableDiv, 'Flesch-Kincaid Grade', this.scores.fleschKincaidGrade.toFixed(1));
        this.addScoreRow(tableDiv, 'Gunning Fog', this.scores.gunningFog.toFixed(1));
        this.addScoreRow(tableDiv, 'Coleman-Liau', this.scores.colemanLiau.toFixed(1));
        this.addScoreRow(tableDiv, 'Automated Readability', this.scores.automatedReadability.toFixed(1));
        this.addScoreRow(tableDiv, 'Dale-Chall', this.scores.daleChall.toFixed(1));
    }

    private addScoreRow(container: HTMLElement, label: string, value: string): void {
        const row = container.createDiv({ cls: 'score-row' });
        row.createSpan({ cls: 'score-label' }).setText(label);
        row.createSpan({ cls: 'score-value' }).setText(value);
    }

    public update(scores: ReadabilityScores | null): void {
        this.scores = scores;
        this.renderContent();
    }
}