import { BasePanel } from './BasePanel';
import { TextStats } from '../../types';
import SmartWriteCompanionPlugin from "../../main";

export class SessionStatsPanel extends BasePanel {
    private plugin: SmartWriteCompanionPlugin;
    private textStats: TextStats | null = null;

    constructor(containerEl: HTMLElement, plugin: SmartWriteCompanionPlugin) {
        super(containerEl, 'Session Stats');
        this.plugin = plugin;
    }

    protected renderContent(): void {
        if (!this.plugin) return;
        
        try {
            this.contentEl.empty();

            const sessionStats = this.plugin.sessionTracker.getCurrentSession();
            const todayProgress = this.plugin.sessionTracker?.getTodayProgress();

            if (!todayProgress) {
                this.contentEl.setText("Loading daily progress...");
                return;
            }

            // Section 1: Session Stats
            const sessionSection = this.contentEl.createDiv({ cls: 'smartwrite-section' });
            
            // Large Word Count
            const largeStat = sessionSection.createDiv({ cls: 'smartwrite-stat-large' });
            largeStat.createSpan({ cls: 'smartwrite-stat-value' }).setText(`${this.formatNumber(sessionStats ? sessionStats.wordsWritten : 0)} words`);
            largeStat.createSpan({ cls: 'smartwrite-stat-label' }).setText('in this session');

            // Time & Pace
            const secondaryStats = sessionSection.createDiv({ cls: 'smartwrite-stat' });
            
            const timeSpan = secondaryStats.createSpan({ cls: 'stat-item' });
            timeSpan.setText(`${this.formatTime(sessionStats ? sessionStats.timeSpent : 0)}`);
            timeSpan.setAttr('title', 'Session Duration');

            const paceSpan = secondaryStats.createSpan({ cls: 'stat-item' });
            paceSpan.setText(`${sessionStats ? Math.round(sessionStats.wpm) : 0} wpm`);
            paceSpan.setAttr('title', 'Writing Pace');

            // Section 2: Daily Goal (Progress Bar)
            const goalSection = this.contentEl.createDiv({ cls: 'smartwrite-section' });
            goalSection.createEl('h4').setText('Daily Goal');

            const progressBar = goalSection.createDiv({ cls: 'smartwrite-progress-bar' });
            const progressFill = progressBar.createDiv({ cls: 'smartwrite-progress-fill' });
            
            // Calculate total for today including current session
            const sessionWords = sessionStats ? sessionStats.wordsWritten : 0;
            const current = (todayProgress.wordsWritten || 0) + sessionWords;
            const goal = todayProgress.goal || 1000;
            
            const percent = this.calculateProgress(current, goal);
            progressFill.style.width = `${percent}%`;

            const progressLabel = goalSection.createDiv({ cls: 'smartwrite-stat-label' });
            progressLabel.style.textAlign = 'right';
            progressLabel.setText(`${this.formatNumber(current)} / ${this.formatNumber(goal)} (${Math.round(percent)}%)`);
        } catch (error) {
            console.error('CRITICAL ERROR in SessionStatsPanel:', error);
            this.contentEl.createDiv().setText(`Render Error: ${error.message}`);
        }
    }

    private formatNumber(num: number): string {
        return num.toLocaleString();
    }

    private formatTime(minutes: number): string {
        if (minutes < 1) {
            return '< 1 min';
        }
        const hrs = Math.floor(minutes / 60);
        const mins = Math.floor(minutes % 60);
        return hrs > 0 ? `${hrs}h ${mins}m` : `${mins} min`;
    }

    private calculateProgress(current: number, goal: number): number {
        return goal > 0 ? Math.min((current / goal) * 100, 100) : 0;
    }

    public update(stats: TextStats | null): void {
        this.textStats = stats;
        this.renderContent();
    }
}