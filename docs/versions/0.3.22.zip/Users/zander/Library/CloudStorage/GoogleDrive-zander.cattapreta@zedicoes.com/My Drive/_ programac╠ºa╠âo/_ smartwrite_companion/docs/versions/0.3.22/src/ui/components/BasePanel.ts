import { Component } from 'obsidian';

export abstract class BasePanel extends Component {
    protected containerEl: HTMLElement;
    protected headerEl: HTMLElement;
    protected contentEl: HTMLElement;
    protected isCollapsed: boolean = false;

    constructor(containerEl: HTMLElement, title: string) {
        super();
        this.containerEl = containerEl;
        this.createPanel(title);
    }

    private createPanel(title: string): void {
        // Create panel container
        const panelEl = this.containerEl.createDiv({ cls: 'smartwrite-panel' });

        // Create header
        this.headerEl = panelEl.createDiv({ cls: 'smartwrite-panel-header' });

        const titleEl = this.headerEl.createDiv({ cls: 'smartwrite-panel-title' });
        titleEl.setText(title);

        const toggleEl = this.headerEl.createDiv({ cls: 'smartwrite-panel-toggle' });
        toggleEl.setText('▼');
        toggleEl.addEventListener('click', () => this.toggle());

        // Create content
        this.contentEl = panelEl.createDiv({ cls: 'smartwrite-panel-content' });

        this.renderContent();
    }

    protected abstract renderContent(): void;

    public updateContent(data?: any): void {
        // Override in subclasses
    }

    private toggle(): void {
        this.isCollapsed = !this.isCollapsed;
        const toggleEl = this.headerEl.querySelector('.smartwrite-panel-toggle');

        if (this.isCollapsed) {
            this.contentEl.style.display = 'none';
            if (toggleEl) toggleEl.setText('▶');
        } else {
            this.contentEl.style.display = 'block';
            if (toggleEl) toggleEl.setText('▼');
        }
    }

    public getContainer(): HTMLElement {
        return this.containerEl;
    }

    public show(): void {
        this.containerEl.style.display = 'block';
    }

    public hide(): void {
        this.containerEl.style.display = 'none';
    }
}