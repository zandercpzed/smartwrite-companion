import { BasePanel } from './BasePanel';
import { SessionStats } from '../../../types';
import { StatsEngine } from '../../core/StatsEngine';

export class SessionStatsPanel extends BasePanel {
    private sessionStats: SessionStats | null = null;
    private statsEngine: StatsEngine;

    constructor(containerEl: HTMLElement) {
        super(containerEl, 'Session Stats');
        this.statsEngine = new StatsEngine();
    }

    protected renderContent(): void {
        this.contentEl.empty();

        if (!this.sessionStats) {
            this.contentEl.setText('No active session');
            return;
        }

        const statsDiv = this.contentEl.createDiv({ cls: 'session-stats' });

        // Words written
        const wordsDiv = statsDiv.createDiv({ cls: 'stat-item' });
        wordsDiv.createSpan({ cls: 'stat-label' }).setText('Words:');
        wordsDiv.createSpan({ cls: 'stat-value' }).setText(this.statsEngine.formatNumber(this.sessionStats.wordsWritten));

        // Time spent
        const timeDiv = statsDiv.createDiv({ cls: 'stat-item' });
        timeDiv.createSpan({ cls: 'stat-label' }).setText('Time:');
        timeDiv.createSpan({ cls: 'stat-value' }).setText(this.statsEngine.formatTime(this.sessionStats.timeSpent));

        // WPM
        const wpmDiv = statsDiv.createDiv({ cls: 'stat-item' });
        wpmDiv.createSpan({ cls: 'stat-label' }).setText('WPM:');
        wpmDiv.createSpan({ cls: 'stat-value' }).setText(Math.round(this.sessionStats.wpm).toString());

        // Progress bar
        const progressDiv = statsDiv.createDiv({ cls: 'progress-container' });
        progressDiv.createSpan({ cls: 'progress-label' }).setText(`Progress: ${Math.round(this.sessionStats.progress)}%`);

        const progressBar = progressDiv.createDiv({ cls: 'progress-bar' });
        const progressFill = progressBar.createDiv({ cls: 'progress-fill' });
        progressFill.style.width = `${this.sessionStats.progress}%`;
    }

    public updateContent(sessionStats: SessionStats): void {
        this.sessionStats = sessionStats;
        this.renderContent();
    }
}