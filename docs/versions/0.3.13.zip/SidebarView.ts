import { ItemView, WorkspaceLeaf } from 'obsidian';
import SmartWriteCompanionPlugin from './main';

export class SidebarView extends ItemView {
    private plugin: SmartWriteCompanionPlugin;

    constructor(leaf: WorkspaceLeaf, plugin: SmartWriteCompanionPlugin) {
        super(leaf);
        this.plugin = plugin;
    }

    getViewType(): string {
        return 'smartwrite-sidebar';
    }

    getDisplayText(): string {
        return 'SmartWrite Companion';
    }

    getIcon(): string {
        return 'pencil';
    }

    async onOpen(): Promise<void> {
        const container = this.containerEl.children[1];
        container.empty();
        container.addClass('smartwrite-sidebar');

        // Create header
        this.createHeader(container);
    }

    private createHeader(container: Element): void {
        const header = container.createDiv({ cls: 'smartwrite-header' });

        // Title container
        const titleContainer = header.createDiv({ cls: 'smartwrite-title-container' });
        const title = titleContainer.createDiv({ cls: 'smartwrite-title' });
        title.setText('SmartWrite Companion');
        const version = titleContainer.createDiv({ cls: 'smartwrite-version' });
        version.setText(`versão: ${this.plugin.manifest.version}`);

        // Settings button (now toggles sidebar)
        const settingsBtn = header.createDiv({ cls: 'smartwrite-settings-btn' });
        settingsBtn.setText('⚙');
        settingsBtn.addEventListener('click', () => this.toggleSidebar());
    }

    private toggleSidebar(): void {
        const leaves = this.app.workspace.getLeavesOfType('smartwrite-sidebar');
        if (leaves.length > 0) {
            this.app.workspace.detachLeavesOfType('smartwrite-sidebar');
        } else {
            this.plugin.activateView();
        }
    }

    async onClose(): Promise<void> {
        // No panels to unload
    }
}