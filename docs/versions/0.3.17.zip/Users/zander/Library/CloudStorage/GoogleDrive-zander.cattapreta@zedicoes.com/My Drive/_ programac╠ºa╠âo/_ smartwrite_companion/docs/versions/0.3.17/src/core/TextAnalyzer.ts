const hyphen = require('hyphen');
const sbd = require('sbd');

import { TextMetrics } from '../types';

export class TextAnalyzer {
    private repetitionThreshold: number;

    constructor(repetitionThreshold: number = 3) {
        this.repetitionThreshold = repetitionThreshold;
    }

    analyze(text: string, language: string): TextMetrics {
        const words = this.extractWords(text);
        const sentences = this.extractSentences(text);
        const paragraphs = this.extractParagraphs(text);
        const characters = text.length;
        const charactersNoSpaces = text.replace(/\s/g, '').length;
        const syllables = this.countSyllables(text, language);
        const wordFrequency = this.calculateWordFrequency(words);
        const repetitions = this.detectRepetitions(wordFrequency);

        return {
            words,
            sentences,
            paragraphs,
            characters,
            charactersNoSpaces,
            syllables,
            wordFrequency,
            repetitions,
        };
    }

    private extractWords(text: string): string[] {
        return text
            .toLowerCase()
            .replace(/[^\w\s]/g, '')
            .split(/\s+/)
            .filter(word => word.length > 0);
    }

    private extractSentences(text: string): string[] {
        return sbd.sentences(text);
    }

    private extractParagraphs(text: string): string[] {
        return text.split(/\n\s*\n/).filter(p => p.trim().length > 0);
    }

    private countSyllables(text: string, language: string): number {
        // Load hyphen pattern for language
        const patterns = require(`hyphen/patterns/${language}`);
        const hyp = hyphen(patterns);

        const words = this.extractWords(text);
        let totalSyllables = 0;

        for (const word of words) {
            const hyphenated = hyp(word);
            const syllables = hyphenated.split('-').length;
            totalSyllables += syllables;
        }

        return totalSyllables;
    }

    private calculateWordFrequency(words: string[]): Map<string, number> {
        const frequency = new Map<string, number>();
        for (const word of words) {
            frequency.set(word, (frequency.get(word) || 0) + 1);
        }
        return frequency;
    }

    private detectRepetitions(wordFrequency: Map<string, number>): Array<{ word: string; count: number }> {
        const repetitions: Array<{ word: string; count: number }> = [];
        for (const [word, count] of wordFrequency) {
            if (count >= this.repetitionThreshold) {
                repetitions.push({ word, count });
            }
        }
        return repetitions;
    }
}