import React, { useState } from 'react';
import { ChevronDown, ChevronRight } from 'lucide-react';

/**
 * COMPONENTE: Suggestions
 *
 * Funcionalidades:
 * - Lista de sugestões de melhoria do texto
 * - Categorização por tipo (Grammar, Style, Clarity, Redundancy)
 * - Sistema de severidade (error, warning, info)
 * - Interface clicável para navegação
 * - Contador de itens no header
 *
 * Sistema de Severidade:
 * - error: Problemas críticos de gramática
 * - warning: Questões de estilo e redundância
 * - info: Sugestões de melhoria de clareza
 */
export function Suggestions() {
  // ESTADO: Controle de expansão do painel
  const [isExpanded, setIsExpanded] = useState(true);

  // DADOS MOCKADOS: Lista de sugestões detectadas
  // Cada item tem: type, description, severity
  const suggestions = [
    {
      type: 'Grammar',
      description: 'Missing comma after introductory phrase',
      severity: 'error'    // Vermelho - erro crítico
    },
    {
      type: 'Style',
      description: 'Consider using active voice',
      severity: 'warning'  // Amarelo - aviso de estilo
    },
    {
      type: 'Clarity',
      description: 'Sentence may be too complex',
      severity: 'info'     // Azul - informação de clareza
    },
    {
      type: 'Grammar',
      description: 'Subject-verb agreement issue',
      severity: 'error'
    },
    {
      type: 'Redundancy',
      description: 'Repeated word in paragraph',
      severity: 'warning'
    },
    {
      type: 'Style',
      description: 'Weak verb usage',
      severity: 'info'
    },
    {
      type: 'Clarity',
      description: 'Ambiguous pronoun reference',
      severity: 'warning'
    }
  ];

  return (
    // CONTAINER DO MÓDULO
    <div className="module">
      {/* HEADER COM CONTADOR: Badge mostra número de sugestões */}
      <button
        className="module-header"
        onClick={() => setIsExpanded(!isExpanded)}
      >
        {isExpanded ? <ChevronDown size={14} /> : <ChevronRight size={14} />}
        <span>Suggestions</span>
        {/* BADGE DE CONTAGEM: Número total de itens */}
        <span className="count-badge">{suggestions.length}</span>
      </button>

      {/* LISTA DE SUGESTÕES: Só renderiza se expandido */}
      {isExpanded && (
        <div className="module-content">
          {/* CONTAINER DA LISTA: Itens clicáveis */}
          <div className="suggestions-list">
            {suggestions.map((item, index) => (
              // ITEM CLICÁVEL: Navega para o problema no texto
              <button
                key={index}
                className="suggestion-item"
                onClick={() => console.log('Navigate to issue:', item)}
              >
                {/* INDICADOR DE SEVERIDADE: Ponto colorido */}
                <span className={`severity-dot severity-${item.severity}`} />

                {/* CONTEÚDO DA SUGESTÃO */}
                <div className="suggestion-content">
                  {/* TIPO DA SUGESTÃO: Grammar, Style, etc. */}
                  <div className="suggestion-type">{item.type}</div>
                  {/* DESCRIÇÃO DETALHADA */}
                  <div className="suggestion-description">{item.description}</div>
                </div>
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
