import { ItemView, WorkspaceLeaf } from 'obsidian';
import SmartWriteCompanionPlugin from './main';
import { BasePanel } from './BasePanel';
import { SessionStatsPanel } from './SessionStatsPanel';
import { TextMetricsPanel } from './TextMetricsPanel';
import { ReadabilityPanel } from './ReadabilityPanel';
import { SuggestionsPanel } from './SuggestionsPanel';
import { PersonaPanel } from './PersonaPanel';
import { TextAnalyzer } from './TextAnalyzer';

export class SidebarView extends ItemView {
    private plugin: SmartWriteCompanionPlugin;
    private panels: BasePanel[] = [];
    private textAnalyzer: TextAnalyzer;

    constructor(leaf: WorkspaceLeaf, plugin: SmartWriteCompanionPlugin) {
        super(leaf);
        this.plugin = plugin;
        this.textAnalyzer = new TextAnalyzer();
    }

    getViewType(): string {
        return 'smartwrite-sidebar';
    }

    getDisplayText(): string {
        return 'SmartWrite Companion';
    }

    async onOpen(): Promise<void> {
        const container = this.containerEl.children[1];
        container.empty();
        container.addClass('smartwrite-sidebar');

        this.createPanels(container);
    }

    private createPanels(container: Element): void {
        // Session Stats Panel
        const sessionContainer = container.createDiv();
        const sessionPanel = new SessionStatsPanel(sessionContainer as HTMLElement);
        this.panels.push(sessionPanel);

        // Text Metrics Panel
        const metricsContainer = container.createDiv();
        const metricsPanel = new TextMetricsPanel(metricsContainer as HTMLElement);
        this.panels.push(metricsPanel);

        // Readability Panel
        const readabilityContainer = container.createDiv();
        const readabilityPanel = new ReadabilityPanel(readabilityContainer as HTMLElement);
        this.panels.push(readabilityPanel);

        // Suggestions Panel
        const suggestionsContainer = container.createDiv();
        const suggestionsPanel = new SuggestionsPanel(suggestionsContainer as HTMLElement);
        this.panels.push(suggestionsPanel);

        // Persona Panel
        const personaContainer = container.createDiv();
        const personaPanel = new PersonaPanel(personaContainer as HTMLElement);
        this.panels.push(personaPanel);
    }

    public updateContent(content: string): void {
        const analysis = this.textAnalyzer.analyze(content);

        // Update session stats
        const sessionStats = this.plugin.sessionTracker.getCurrentSession();
        if (sessionStats) {
            this.plugin.sessionTracker.updateWords(analysis.words);
            const updatedSession = this.plugin.sessionTracker.getCurrentSession();
            if (updatedSession) {
                const sessionPanel = this.panels.find(p => p instanceof SessionStatsPanel) as SessionStatsPanel;
                if (sessionPanel) {
                    sessionPanel.updateContent(updatedSession);
                }
            }
        }

        // Update text metrics
        const metricsPanel = this.panels.find(p => p instanceof TextMetricsPanel) as TextMetricsPanel;
        if (metricsPanel) {
            metricsPanel.updateContent(analysis);
        }
    }

    async onClose(): Promise<void> {
        this.panels.forEach(panel => panel.unload());
        this.panels = [];
    }
}