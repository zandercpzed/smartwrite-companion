import { BasePanel } from './BasePanel';

export class SuggestionsPanel extends BasePanel {
    constructor(containerEl: HTMLElement) {
        super(containerEl, 'Suggestions');
    }

    protected renderContent(): void {
        this.contentEl.empty();
        this.contentEl.setText('Writing suggestions coming soon...');
    }
}