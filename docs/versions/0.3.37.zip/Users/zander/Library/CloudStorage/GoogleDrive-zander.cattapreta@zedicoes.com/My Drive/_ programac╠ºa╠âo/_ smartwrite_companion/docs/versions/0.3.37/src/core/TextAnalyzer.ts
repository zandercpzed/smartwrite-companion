import { TextMetrics, Language } from '../types';
import * as sbd from 'sbd';
import { hyphenateSync } from 'hyphen/en';

export class TextAnalyzer {
    private wordPattern = /[\wÀ-ÿ'-]+/g;

    public analyze(text: string, language: Language = 'en'): TextMetrics {
        const words = this.extractWords(text);
        const sentences = this.extractSentences(text); // sbd handles multiple languages somewhat, but explicit config could be better
        const paragraphs = this.extractParagraphs(text);
        const characters = text.length;
        const charactersNoSpaces = text.replace(/\s/g, '').length;
        
        // Syllable counting
        // Since hyphen is a single language import in this basic setup (en), we only support EN for syllables clearly.
        // For production multilingual, we'd need to dynamically load hyphenation patterns.
        // For MVP phase 2, we stick to EN or basic heuristics if not EN, or just use EN hyphenator (it works okayish for latin scripts as fallback)
        const syllables = this.countSyllables(words);

        const { frequency, repetitions } = this.analyzeFrequencies(words);

        return {
            words,
            sentences,
            paragraphs,
            characters,
            charactersNoSpaces,
            syllables,
            wordFrequency: frequency,
            repetitions
        };
    }

    private extractWords(text: string): string[] {
        return text.match(this.wordPattern) || [];
    }

    private extractSentences(text: string): string[] {
        // Basic usage of sbd. For better accuracy, pass options based on language.
        return sbd.sentences(text) || [];
    }

    private extractParagraphs(text: string): string[] {
        return text.split(/\n\s*\n/).filter(p => p.trim().length > 0);
    }

    private countSyllables(words: string[]): number {
        let totalSyllables = 0;
        
        for (const word of words) {
            // hyphenateSync returns text with soft hyphens, e.g. "ex-am-ple" (depends on config, default might be \u00AD)
            // Or usually hyphenates string. The library 'hyphen' returns a function.
            // Let's verify usage. Actually 'hyphen' package exports a factory. 
            // Importing 'hyphen/en' gives a hyphenator function usually.
            // Let's assume standard usage for now.
            const hyphenated = hyphenateSync(word);
            // Count segments separated by hyphen (soft hyphen or explicit if configured, hyphen/en default uses \u00AD soft hyphen)
            const segments = hyphenated.split(/\u00AD/);
            totalSyllables += segments.length;
        }

        return totalSyllables;
    }

    private analyzeFrequencies(words: string[]): { frequency: Map<string, number>, repetitions: Array<{ word: string, count: number }> } {
        const frequency = new Map<string, number>();
        const lowerWords = words.map(w => w.toLowerCase());

        for (const word of lowerWords) {
            frequency.set(word, (frequency.get(word) || 0) + 1);
        }

        // Filter repetitions (e.g. appearing more than 3 times, configurable in future)
        const repetitions: Array<{ word: string, count: number }> = [];
        for (const [word, count] of frequency.entries()) {
            if (count > 3 && word.length > 3) { // Ignore short words
                repetitions.push({ word, count });
            }
        }
        
        repetitions.sort((a, b) => b.count - a.count);

        return { frequency, repetitions };
    }
}