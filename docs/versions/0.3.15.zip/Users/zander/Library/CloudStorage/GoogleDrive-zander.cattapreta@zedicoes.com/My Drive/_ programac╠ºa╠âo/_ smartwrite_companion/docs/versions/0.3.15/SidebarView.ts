import { ItemView, WorkspaceLeaf } from 'obsidian';
import SmartWriteCompanionPlugin from './main';
import { TextStats, SuggestionsResult, ReadabilityScores } from './types';
import { SessionStatsPanel } from './src/ui/components/SessionStatsPanel';
import { TextMetricsPanel } from './src/ui/components/TextMetricsPanel';
import { SuggestionsPanel } from './src/ui/components/SuggestionsPanel';
import { ReadabilityPanel } from './src/ui/components/ReadabilityPanel';

export class SidebarView extends ItemView {
    private plugin: SmartWriteCompanionPlugin;
    private sessionStatsPanel: SessionStatsPanel;
    private textMetricsPanel: TextMetricsPanel;
    private suggestionsPanel: SuggestionsPanel;
    private readabilityPanel: ReadabilityPanel;

    constructor(leaf: WorkspaceLeaf, plugin: SmartWriteCompanionPlugin) {
        super(leaf);
        this.plugin = plugin;
    }

    getViewType(): string {
        return 'smartwrite-sidebar';
    }

    getDisplayText(): string {
        return 'SmartWrite Companion';
    }

    getIcon(): string {
        return 'pencil';
    }

    async onOpen(): Promise<void> {
        const container = this.containerEl.children[1];
        container.empty();
        container.addClass('smartwrite-sidebar');

        // Create header
        this.createHeader(container);

        // Create panels container
        const panelsContainer = container.createDiv({ cls: 'smartwrite-panels' });

        // Initialize panels
        this.sessionStatsPanel = new SessionStatsPanel(panelsContainer, this.plugin);
        this.textMetricsPanel = new TextMetricsPanel(panelsContainer, this.plugin);
        this.suggestionsPanel = new SuggestionsPanel(panelsContainer, this.plugin);
        this.readabilityPanel = new ReadabilityPanel(panelsContainer, this.plugin);

        // Initial render
        this.updateContent(null, null, null);
    }

    private createHeader(container: Element): void {
        const header = container.createDiv({ cls: 'smartwrite-header' });

        // Title container
        const titleContainer = header.createDiv({ cls: 'smartwrite-title-container' });
        const title = titleContainer.createDiv({ cls: 'smartwrite-title' });
        title.setText('SmartWrite Companion');
        const version = titleContainer.createDiv({ cls: 'smartwrite-version' });
        version.setText(`versão: ${this.plugin.manifest.version}`);

        // Settings button (now toggles sidebar)
        const settingsBtn = header.createDiv({ cls: 'smartwrite-settings-btn' });
        settingsBtn.setText('⚙');
        settingsBtn.addEventListener('click', () => this.toggleSidebar());
    }

    private toggleSidebar(): void {
        const leaves = this.app.workspace.getLeavesOfType('smartwrite-sidebar');
        if (leaves.length > 0) {
            this.app.workspace.detachLeavesOfType('smartwrite-sidebar');
        } else {
            this.plugin.activateView();
        }
    }

    updateContent(stats: TextStats | null, suggestions: SuggestionsResult | null, readability: ReadabilityScores | null): void {
        if (this.sessionStatsPanel) {
            this.sessionStatsPanel.update(stats);
        }
        if (this.textMetricsPanel) {
            this.textMetricsPanel.update(stats);
        }
        if (this.suggestionsPanel) {
            this.suggestionsPanel.update(suggestions);
        }
        if (this.readabilityPanel) {
            this.readabilityPanel.update(readability);
        }
    }
}