import { BasePanel } from './BasePanel';
import { TextStats } from '../../../types';
import SmartWriteCompanionPlugin from '../../../main';

export class TextMetricsPanel extends BasePanel {
    private plugin: SmartWriteCompanionPlugin;
    private stats: TextStats | null = null;

    constructor(containerEl: HTMLElement, plugin: SmartWriteCompanionPlugin) {
        super(containerEl, 'Text Metrics');
        this.plugin = plugin;
    }

    protected renderContent(): void {
        this.contentEl.empty();

        if (!this.stats) {
            this.contentEl.setText('No text to analyze');
            return;
        }

        // LISTA DE MÉTRICAS: Formatação consistente
        const metricsList = this.contentEl.createDiv({ cls: 'metrics-list' });

        // MÉTRICA: Palavras
        const wordsRow = metricsList.createDiv({ cls: 'metric-row' });
        wordsRow.createSpan({ cls: 'stat-label' }).setText('Words');
        wordsRow.createSpan({ cls: 'stat-mono' }).setText(this.stats.wordCount.toLocaleString());

        // MÉTRICA: Caracteres totais
        const charsRow = metricsList.createDiv({ cls: 'metric-row' });
        charsRow.createSpan({ cls: 'stat-label' }).setText('Characters');
        charsRow.createSpan({ cls: 'stat-mono' }).setText(this.stats.characterCount.toLocaleString());

        // MÉTRICA: Caracteres sem espaços (indentada)
        const charsNoSpacesRow = metricsList.createDiv({ cls: 'metric-row metric-indent' });
        charsNoSpacesRow.createSpan({ cls: 'stat-label' }).setText('No spaces');
        charsNoSpacesRow.createSpan({ cls: 'stat-mono' }).setText(this.stats.characterCountNoSpaces.toLocaleString());

        // MÉTRICA: Número de sentenças
        const sentencesRow = metricsList.createDiv({ cls: 'metric-row' });
        sentencesRow.createSpan({ cls: 'stat-label' }).setText('Sentences');
        sentencesRow.createSpan({ cls: 'stat-mono' }).setText(this.stats.sentenceCount.toString());

        // MÉTRICA: Número de parágrafos
        const paragraphsRow = metricsList.createDiv({ cls: 'metric-row' });
        paragraphsRow.createSpan({ cls: 'stat-label' }).setText('Paragraphs');
        paragraphsRow.createSpan({ cls: 'stat-mono' }).setText(this.stats.paragraphCount.toString());

        // MÉTRICA: Sílabas
        const syllablesRow = metricsList.createDiv({ cls: 'metric-row' });
        syllablesRow.createSpan({ cls: 'stat-label' }).setText('Syllables');
        syllablesRow.createSpan({ cls: 'stat-mono' }).setText(this.stats.syllableCount.toString());

        // MÉTRICA: Comprimento médio da palavra
        const avgWordRow = metricsList.createDiv({ cls: 'metric-row' });
        avgWordRow.createSpan({ cls: 'stat-label' }).setText('Avg word length');
        avgWordRow.createSpan({ cls: 'stat-mono' }).setText(this.stats.averageWordLength.toFixed(1));

        // MÉTRICA: Comprimento médio da sentença
        const avgSentenceRow = metricsList.createDiv({ cls: 'metric-row' });
        avgSentenceRow.createSpan({ cls: 'stat-label' }).setText('Avg sentence length');
        avgSentenceRow.createSpan({ cls: 'stat-mono' }).setText(this.stats.averageSentenceLength.toFixed(1));

        // MÉTRICA: Sílabas por palavra
        const syllablesPerWordRow = metricsList.createDiv({ cls: 'metric-row' });
        syllablesPerWordRow.createSpan({ cls: 'stat-label' }).setText('Syllables/word');
        syllablesPerWordRow.createSpan({ cls: 'stat-mono' }).setText(this.stats.averageSyllablesPerWord.toFixed(1));

        // MÉTRICA: Tempo de leitura estimado
        const readingRow = metricsList.createDiv({ cls: 'metric-row' });
        readingRow.createSpan({ cls: 'stat-label' }).setText('Reading time');
        readingRow.createSpan({ cls: 'stat-mono' }).setText(this.plugin.statsEngine.formatTime(this.stats.readingTimeMinutes));

        // MÉTRICA: Vocabulário único
        const uniqueRow = metricsList.createDiv({ cls: 'metric-row' });
        uniqueRow.createSpan({ cls: 'stat-label' }).setText('Unique words');
        uniqueRow.createSpan({ cls: 'stat-mono' }).setText(this.stats.wordFrequency.size.toString());
    }

    public update(stats: TextStats | null): void {
        this.stats = stats;
        this.renderContent();
    }
}