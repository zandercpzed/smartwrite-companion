import { TextMetrics, Suggestion, SuggestionsResult } from '../../types';

export class SuggestionEngine {
    private passiveVoicePatterns: RegExp[];
    private cliches: Set<string>;
    private longSentenceThreshold: number;
    private repetitionThreshold: number;

    constructor(options: {
        longSentenceThreshold?: number;
        repetitionThreshold?: number;
    } = {}) {
        this.longSentenceThreshold = options.longSentenceThreshold || 25;
        this.repetitionThreshold = options.repetitionThreshold || 3;

        // Passive voice patterns (basic detection)
        this.passiveVoicePatterns = [
            /\b(is|are|was|were|be|been|being)\s+(\w+ed|\w+en)\b/gi,
            /\b(has|have|had)\s+been\s+(\w+ed|\w+en)\b/gi,
        ];

        // Common clichés (expandable)
        this.cliches = new Set([
            'at the end of the day',
            'in this day and age',
            'time will tell',
            'easier said than done',
            'last but not least',
            'the bottom line',
            'make no mistake',
            'it goes without saying',
        ]);
    }

    analyze(text: string, metrics: TextMetrics): SuggestionsResult {
        const suggestions: Suggestion[] = [];

        // Detect repetitions
        suggestions.push(...this.detectRepetitions(metrics));

        // Detect passive voice
        suggestions.push(...this.detectPassiveVoice(text));

        // Detect clichés
        suggestions.push(...this.detectCliches(text));

        // Detect long sentences
        suggestions.push(...this.detectLongSentences(metrics.sentences));

        // Detect complex words (basic heuristic)
        suggestions.push(...this.detectComplexWords(metrics.words));

        // Use write-good for additional suggestions
        suggestions.push(...this.useWriteGood(text));

        const summary = this.createSummary(suggestions);

        return {
            suggestions,
            summary,
        };
    }

    private detectRepetitions(metrics: TextMetrics): Suggestion[] {
        const suggestions: Suggestion[] = [];
        let id = 0;

        for (const rep of metrics.repetitions) {
            suggestions.push({
                id: `rep-${id++}`,
                type: 'repetition',
                severity: rep.count >= 5 ? 'high' : 'medium',
                message: `Word "${rep.word}" is repeated ${rep.count} times`,
                position: { start: 0, end: 0 }, // Would need text position tracking
                replacement: `Consider varying your vocabulary instead of repeating "${rep.word}"`,
                explanation: 'Repetition can make writing monotonous. Try using synonyms or rephrasing.',
            });
        }

        return suggestions;
    }

    private detectPassiveVoice(text: string): Suggestion[] {
        const suggestions: Suggestion[] = [];
        let id = 0;

        for (const pattern of this.passiveVoicePatterns) {
            let match;
            while ((match = pattern.exec(text)) !== null) {
                suggestions.push({
                    id: `passive-${id++}`,
                    type: 'passive',
                    severity: 'medium',
                    message: `Passive voice detected: "${match[0]}"`,
                    position: {
                        start: match.index,
                        end: match.index + match[0].length,
                    },
                    explanation: 'Active voice is generally more engaging and direct.',
                });
            }
        }

        return suggestions;
    }

    private detectCliches(text: string): Suggestion[] {
        const suggestions: Suggestion[] = [];
        let id = 0;
        const lowerText = text.toLowerCase();

        for (const cliche of this.cliches) {
            const index = lowerText.indexOf(cliche);
            if (index !== -1) {
                suggestions.push({
                    id: `cliche-${id++}`,
                    type: 'cliche',
                    severity: 'low',
                    message: `Cliché detected: "${cliche}"`,
                    position: {
                        start: index,
                        end: index + cliche.length,
                    },
                    explanation: 'Clichés can make writing feel stale. Consider more original expressions.',
                });
            }
        }

        return suggestions;
    }

    private detectLongSentences(sentences: string[]): Suggestion[] {
        const suggestions: Suggestion[] = [];
        let id = 0;
        let currentPos = 0;

        for (const sentence of sentences) {
            const wordCount = sentence.split(/\s+/).length;
            if (wordCount > this.longSentenceThreshold) {
                suggestions.push({
                    id: `long-${id++}`,
                    type: 'long-sentence',
                    severity: wordCount > 40 ? 'high' : 'medium',
                    message: `Long sentence (${wordCount} words)`,
                    position: {
                        start: currentPos,
                        end: currentPos + sentence.length,
                    },
                    explanation: 'Long sentences can be hard to follow. Consider breaking them up.',
                });
            }
            currentPos += sentence.length + 1; // +1 for period/space
        }

        return suggestions;
    }

    private detectComplexWords(words: string[]): Suggestion[] {
        const suggestions: Suggestion[] = [];
        let id = 0;

        // Simple heuristic: words longer than 12 characters might be complex
        const complexWords = words.filter(word => word.length > 12);

        for (const word of complexWords) {
            suggestions.push({
                id: `complex-${id++}`,
                type: 'complex-word',
                severity: 'low',
                message: `Potentially complex word: "${word}"`,
                position: { start: 0, end: 0 }, // Would need position tracking
                explanation: 'Consider if a simpler word would work better for your audience.',
            });
        }

        return suggestions;
    }

    private useWriteGood(text: string): Suggestion[] {
        const suggestions: Suggestion[] = [];

        try {
            // Import write-good dynamically to avoid issues
            const writeGood = require('write-good');

            const suggestions_raw = writeGood(text, {
                passive: true,
                illusion: true,
                so: true,
                thereIs: true,
                weasel: true,
                adverb: true,
                tooWordy: true,
                cliches: true,
            });

            suggestions_raw.forEach((suggestion: any, index: number) => {
                suggestions.push({
                    id: `writegood-${index}`,
                    type: this.mapWriteGoodType(suggestion.reason),
                    severity: 'medium',
                    message: suggestion.reason,
                    position: {
                        start: suggestion.index || 0,
                        end: (suggestion.index || 0) + (suggestion.offset || 0),
                    },
                    replacement: suggestion.replacement,
                });
            });
        } catch (error) {
            console.warn('Write-good analysis failed:', error);
        }

        return suggestions;
    }

    private mapWriteGoodType(reason: string): Suggestion['type'] {
        if (reason.includes('passive')) return 'passive';
        if (reason.includes('cliché') || reason.includes('cliche')) return 'cliche';
        if (reason.includes('wordy') || reason.includes('adverb')) return 'grammar';
        return 'grammar';
    }

    private createSummary(suggestions: Suggestion[]) {
        const byType: Record<string, number> = {};
        const bySeverity: Record<string, number> = {};

        for (const suggestion of suggestions) {
            byType[suggestion.type] = (byType[suggestion.type] || 0) + 1;
            bySeverity[suggestion.severity] = (bySeverity[suggestion.severity] || 0) + 1;
        }

        return {
            total: suggestions.length,
            byType,
            bySeverity,
        };
    }
}