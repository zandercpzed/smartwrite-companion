import { BasePanel } from './BasePanel';
import { TextStats } from '../../../types';
import SmartWriteCompanionPlugin from '../../../main';

export class SessionStatsPanel extends BasePanel {
    private plugin: SmartWriteCompanionPlugin;
    private textStats: TextStats | null = null;

    constructor(containerEl: HTMLElement, plugin: SmartWriteCompanionPlugin) {
        super(containerEl, 'Session Stats');
        this.plugin = plugin;
    }

    protected renderContent(): void {
        this.contentEl.empty();

        const sessionStats = this.plugin.sessionTracker.getCurrentSession();
        const todayProgress = this.plugin.sessionTracker.getTodayProgress();

        const statsDiv = this.contentEl.createDiv({ cls: 'session-stats' });

        // Current session stats
        if (sessionStats) {
            const sessionDiv = statsDiv.createDiv({ cls: 'current-session' });
            sessionDiv.createEl('h4').setText('Current Session');

            // Words written in session
            const wordsDiv = sessionDiv.createDiv({ cls: 'stat-item' });
            wordsDiv.createSpan({ cls: 'stat-label' }).setText('Words:');
            wordsDiv.createSpan({ cls: 'stat-value' }).setText(this.plugin.statsEngine.formatNumber(sessionStats.wordsWritten));

            // Time spent
            const timeDiv = sessionDiv.createDiv({ cls: 'stat-item' });
            timeDiv.createSpan({ cls: 'stat-label' }).setText('Time:');
            timeDiv.createSpan({ cls: 'stat-value' }).setText(this.plugin.statsEngine.formatTime(sessionStats.timeSpent));

            // WPM
            const wpmDiv = sessionDiv.createDiv({ cls: 'stat-item' });
            wpmDiv.createSpan({ cls: 'stat-label' }).setText('WPM:');
            wpmDiv.createSpan({ cls: 'stat-value' }).setText(Math.round(sessionStats.wpm).toString());
        }

        // Daily progress
        const dailyDiv = statsDiv.createDiv({ cls: 'daily-progress' });
        dailyDiv.createEl('h4').setText('Daily Goal');

        const progressDiv = dailyDiv.createDiv({ cls: 'progress-container' });
        progressDiv.createSpan({ cls: 'progress-label' }).setText(`${this.plugin.statsEngine.formatNumber(todayProgress.wordsWritten)} / ${this.plugin.statsEngine.formatNumber(todayProgress.goal)} words`);

        const progressBar = progressDiv.createDiv({ cls: 'progress-bar' });
        const progressFill = progressBar.createDiv({ cls: 'progress-fill' });
        const progressPercent = this.plugin.statsEngine.calculateProgress(todayProgress.wordsWritten, todayProgress.goal);
        progressFill.style.width = `${progressPercent}%`;
    }

    public update(stats: TextStats | null): void {
        this.textStats = stats;
        this.renderContent();
    }
}