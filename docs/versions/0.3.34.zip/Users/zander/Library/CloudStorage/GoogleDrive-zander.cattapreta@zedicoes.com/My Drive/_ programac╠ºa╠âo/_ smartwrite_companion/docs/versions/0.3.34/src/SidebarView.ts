import { ItemView, WorkspaceLeaf, Menu } from 'obsidian';
import SmartWriteCompanionPlugin from './main';
import { TextStats, SuggestionsResult, ReadabilityScores } from './types';
import { SessionStatsPanel } from './ui/components/SessionStatsPanel';
import { TextMetricsPanel } from './ui/components/TextMetricsPanel';
import { SuggestionsPanel } from './ui/components/SuggestionsPanel';
import { ReadabilityPanel } from './ui/components/ReadabilityPanel';
import { PersonaPanel } from './ui/components/PersonaPanel';

export class SidebarView extends ItemView {
    private plugin: SmartWriteCompanionPlugin;
    private sessionStatsPanel: SessionStatsPanel;
    private textMetricsPanel: TextMetricsPanel;
    private suggestionsPanel: SuggestionsPanel;
    private readabilityPanel: ReadabilityPanel;
    private personaPanel: PersonaPanel;

    constructor(leaf: WorkspaceLeaf, plugin: SmartWriteCompanionPlugin) {
        super(leaf);
        this.plugin = plugin;
    }

    getViewType(): string {
        return 'smartwrite-sidebar';
    }

    getDisplayText(): string {
        return 'SmartWrite Companion';
    }

    getIcon(): string {
        return 'pencil';
    }

    async onOpen(): Promise<void> {
        const container = this.containerEl.children[1];
        container.empty();
        container.addClass('smartwrite-container');

        // Create header
        this.createHeader(container);

        // Create panels container
        const panelsContainer = container.createDiv({ cls: 'smartwrite-panels-container' });

        // Initialize panels
        // Initialize panels
        try {
            this.sessionStatsPanel = new SessionStatsPanel(panelsContainer, this.plugin);
        } catch (e) { console.error('Failed to load SessionStatsPanel', e); panelsContainer.createDiv().setText('Error loading SessionStatsPanel'); }

        try {
            this.textMetricsPanel = new TextMetricsPanel(panelsContainer, this.plugin);
        } catch (e) { console.error('Failed to load TextMetricsPanel', e); panelsContainer.createDiv().setText('Error loading TextMetricsPanel'); }

        try {
            this.suggestionsPanel = new SuggestionsPanel(panelsContainer, this.plugin);
        } catch (e) { console.error('Failed to load SuggestionsPanel', e); panelsContainer.createDiv().setText('Error loading SuggestionsPanel'); }

        try {
            this.readabilityPanel = new ReadabilityPanel(panelsContainer, this.plugin);
        } catch (e) { console.error('Failed to load ReadabilityPanel', e); panelsContainer.createDiv().setText('Error loading ReadabilityPanel'); }

        try {
            this.personaPanel = new PersonaPanel(panelsContainer, this.plugin);
        } catch (e) { console.error('Failed to load PersonaPanel', e); panelsContainer.createDiv().setText('Error loading PersonaPanel'); }

        // Initial render
        this.updateContent(null, null, null);
        
        // Fix settings visibility state
        this.refreshPanels();
    }

    private createHeader(container: Element): void {
        const header = container.createDiv({ cls: 'smartwrite-header' });

        // Title container
        const titleContainer = header.createDiv({ cls: 'smartwrite-title-container' });
        const title = titleContainer.createDiv({ cls: 'smartwrite-title' });
        title.setText('SmartWrite Companion');
        const version = titleContainer.createDiv({ cls: 'smartwrite-version' });
        version.setText(`versão: ${this.plugin.manifest.version}`);

        // Settings button
        const settingsBtn = header.createDiv({ cls: 'smartwrite-settings-btn' });
        settingsBtn.setText('⚙'); // Use simple char first to guarantee visibility, or icon if feasible
        
        // Attempt to use Obsidian icon if available, fallback to text
        import('obsidian').then(({ setIcon }) => {
            setIcon(settingsBtn, 'settings');
        });

        settingsBtn.addEventListener('click', (event) => this.showSettingsMenu(event));
    }

    private showSettingsMenu(event: MouseEvent): void {
        const menu = new Menu();

        menu.addItem((item) =>
            item
                .setTitle('Show Session Stats')
                .setChecked(this.plugin.settings.showSessionStats)
                .onClick(async () => {
                    this.plugin.settings.showSessionStats = !this.plugin.settings.showSessionStats;
                    await this.plugin.saveSettings();
                    this.refreshPanels();
                })
        );

        menu.addItem((item) =>
            item
                .setTitle('Show Text Metrics')
                .setChecked(this.plugin.settings.showTextMetrics)
                .onClick(async () => {
                    this.plugin.settings.showTextMetrics = !this.plugin.settings.showTextMetrics;
                    await this.plugin.saveSettings();
                    this.refreshPanels();
                })
        );

        menu.addItem((item) =>
            item
                .setTitle('Show Suggestions')
                .setChecked(this.plugin.settings.showSuggestions)
                .onClick(async () => {
                    this.plugin.settings.showSuggestions = !this.plugin.settings.showSuggestions;
                    await this.plugin.saveSettings();
                    this.refreshPanels();
                })
        );

        menu.addItem((item) =>
            item
                .setTitle('Show Readability')
                .setChecked(this.plugin.settings.showReadability)
                .onClick(async () => {
                    this.plugin.settings.showReadability = !this.plugin.settings.showReadability;
                    await this.plugin.saveSettings();
                    this.refreshPanels();
                })
        );

        menu.addItem((item) =>
            item
                .setTitle('Show Persona Analysis')
                .setChecked(this.plugin.settings.showPersona)
                .onClick(async () => {
                    this.plugin.settings.showPersona = !this.plugin.settings.showPersona;
                    await this.plugin.saveSettings();
                    this.refreshPanels();
                })
        );
        
        menu.addSeparator();
        
        menu.addItem((item) => 
            item
                .setTitle('More Settings...')
                .setIcon('settings')
                .onClick(() => {
                    // Open plugin settings tab
                    (this.app as any).setting.open();
                    (this.app as any).setting.openTabById(this.plugin.manifest.id);
                })
        );

        menu.showAtMouseEvent(event);
    }

    private refreshPanels(): void {
        const settings = this.plugin.settings;
        if (this.sessionStatsPanel) settings.showSessionStats ? this.sessionStatsPanel.show() : this.sessionStatsPanel.hide();
        if (this.textMetricsPanel) settings.showTextMetrics ? this.textMetricsPanel.show() : this.textMetricsPanel.hide();
        if (this.suggestionsPanel) settings.showSuggestions ? this.suggestionsPanel.show() : this.suggestionsPanel.hide();
        if (this.readabilityPanel) settings.showReadability ? this.readabilityPanel.show() : this.readabilityPanel.hide();
        if (this.personaPanel) settings.showPersona ? this.personaPanel.show() : this.personaPanel.hide();
    }

    private toggleSidebar(): void {
        const leaves = this.app.workspace.getLeavesOfType('smartwrite-sidebar');
        if (leaves.length > 0) {
            this.app.workspace.detachLeavesOfType('smartwrite-sidebar');
        } else {
            this.plugin.activateView();
        }
    }

    updateContent(stats: TextStats | null, suggestions: SuggestionsResult | null, readability: ReadabilityScores | null): void {
        if (this.sessionStatsPanel) {
            try { this.sessionStatsPanel.update(stats); } catch(e) { console.error('Error updating SessionStats', e); }
        }
        if (this.textMetricsPanel) {
            try { this.textMetricsPanel.update(stats); } catch(e) { console.error('Error updating TextMetrics', e); }
        }
        if (this.suggestionsPanel) {
            try { this.suggestionsPanel.update(suggestions); } catch(e) { console.error('Error updating Suggestions', e); }
        }
        if (this.readabilityPanel) {
            try { this.readabilityPanel.update(readability); } catch(e) { console.error('Error updating Readability', e); }
        }
        if (this.personaPanel) {
            try { this.personaPanel.update(null); } catch(e) { console.error('Error updating Persona', e); }
        }
    }
}