import React, { useState } from 'react';
import { ChevronDown, ChevronRight } from 'lucide-react';

/**
 * COMPONENTE: PersonaAnalysis
 *
 * Funcionalidades:
 * - Análise de texto baseada em personas de escrita
 * - Integração simulada com Ollama (LLM local)
 * - Seleção de persona (Academic, Journalist, Creative, etc.)
 * - Status de conexão com serviço LLM
 * - Resultados expansíveis da análise
 *
 * Estados:
 * - Seleção de persona via dropdown
 * - Status de conexão (connected/offline)
 * - Loading durante análise
 * - Resultados da análise LLM
 */
export function PersonaAnalysis() {
  // ESTADO: Controle de expansão do painel
  const [isExpanded, setIsExpanded] = useState(true);

  // ESTADO: Persona selecionada
  const [selectedPersona, setSelectedPersona] = useState('academic');

  // ESTADO: Status de análise (loading)
  const [isAnalyzing, setIsAnalyzing] = useState(false);

  // ESTADO: Resultado da análise LLM
  const [analysisResult, setAnalysisResult] = useState('');

  // ESTADO: Controle de expansão dos resultados
  const [isResultExpanded, setIsResultExpanded] = useState(true);

  // ESTADO: Status de conexão com Ollama
  const [ollamaConnected, setOllamaConnected] = useState(true);

  // DADOS: Lista de personas disponíveis
  const personas = [
    { value: 'academic', label: 'Academic Writer' },
    { value: 'journalist', label: 'Journalist' },
    { value: 'creative', label: 'Creative Writer' },
    { value: 'technical', label: 'Technical Writer' },
    { value: 'business', label: 'Business Professional' }
  ];

  /**
   * HANDLER: Executa análise da persona
   * Simula chamada para LLM (Ollama) com feedback personalizado
   */
  const handleAnalyze = () => {
    if (!ollamaConnected) return;

    setIsAnalyzing(true);
    // SIMULAÇÃO: API call com delay
    setTimeout(() => {
      setAnalysisResult(
        `Your writing aligns well with the ${personas.find(p => p.value === selectedPersona)?.label.toLowerCase()} style. The tone is appropriately formal with clear argumentation. Consider varying sentence structure to enhance readability and engage your academic audience more effectively.`
      );
      setIsAnalyzing(false);
      setIsResultExpanded(true);
    }, 1500);
  };

  return (
    // CONTAINER DO MÓDULO
    <div className="module">
      {/* HEADER EXPANSÍVEL */}
      <button
        className="module-header"
        onClick={() => setIsExpanded(!isExpanded)}
      >
        {isExpanded ? <ChevronDown size={14} /> : <ChevronRight size={14} />}
        <span>Persona Analysis</span>
      </button>

      {/* CONTEÚDO: Interface de análise por persona */}
      {isExpanded && (
        <div className="module-content">
          {/* CONTROLES: Seleção de persona e botão de análise */}
          <div className="persona-controls">
            {/* DROPDOWN DE PERSONA: Seleção do estilo de escrita */}
            <select
              value={selectedPersona}
              onChange={(e) => setSelectedPersona(e.target.value)}
              className="persona-dropdown"
              disabled={!ollamaConnected}  // Desabilitado se offline
            >
              {personas.map(persona => (
                <option key={persona.value} value={persona.value}>
                  {persona.label}
                </option>
              ))}
            </select>

            {/* BOTÃO DE ANÁLISE: Executa análise LLM */}
            <button
              className="analyze-btn"
              onClick={handleAnalyze}
              disabled={!ollamaConnected || isAnalyzing}
            >
              {isAnalyzing ? 'Analyzing...' : 'Analyze'}
            </button>
          </div>

          {/* STATUS DE CONEXÃO: Indicador visual + botão de reconexão */}
          <div className="ollama-status">
            {/* INDICADOR VISUAL: Conectado/Offline */}
            <span className={`status-indicator ${ollamaConnected ? 'connected' : 'offline'}`} />
            <span className="status-text">
              {ollamaConnected ? 'Ollama connected' : 'Ollama offline'}
            </span>
            {!ollamaConnected && (
              // BOTÃO DE RECONEXÃO: Simula reconexão
              <button
                className="connect-link"
                onClick={() => setOllamaConnected(true)}
              >
                Connect
              </button>
            )}
          </div>

          {/* RESULTADOS DA ANÁLISE: Só mostra se há resultado */}
          {analysisResult && (
            <div className="analysis-results">
              {/* HEADER EXPANSÍVEL DOS RESULTADOS */}
              <button
                className="results-header"
                onClick={() => setIsResultExpanded(!isResultExpanded)}
              >
                {isResultExpanded ? <ChevronDown size={12} /> : <ChevronRight size={12} />}
                <span>Analysis Results</span>
              </button>

              {/* CONTEÚDO DOS RESULTADOS: Feedback personalizado da LLM */}
              {isResultExpanded && (
                <div className="results-content">
                  {analysisResult}
                </div>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
