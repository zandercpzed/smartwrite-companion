# Plugin review guidelines

This document listed the most common suggestions and feedback that plugin authors receive when they submit their plugin for review.

Its content has moved to [Plugin guidelines](https://docs.obsidian.md/Plugins/Releasing/Plugin+guidelines) in the [Obsidian Developer Docs](https://docs.obsidian.md/).
