import { BasePanel } from './BasePanel';
import { SuggestionsResult } from '../../types';
import SmartWriteCompanionPlugin from "../../main";

export class SuggestionsPanel extends BasePanel {
    private plugin: SmartWriteCompanionPlugin;
    private suggestions: SuggestionsResult | null = null;

    constructor(containerEl: HTMLElement, plugin: SmartWriteCompanionPlugin) {
        super(containerEl, 'Suggestions');
        this.plugin = plugin;
    }

    protected renderContent(): void {
        if (!this.plugin) return;
        this.contentEl.empty();

        if (!this.suggestions || this.suggestions.suggestions.length === 0) {
            this.contentEl.createDiv({ cls: 'smartwrite-no-suggestions' }).setText('No suggestions available');
            this.updateBadge('');
            return;
        }

        // Update badge (shows number of categories/aggregated items now)
        this.updateBadge(this.suggestions.suggestions.length);

        const listContainer = this.contentEl.createDiv({ cls: 'smartwrite-suggestions-list' });

        for (const suggestion of this.suggestions.suggestions) {
            const item = listContainer.createDiv({ cls: 'smartwrite-suggestion-item' });
            
            // Check if expandable (Repetitions)
            const isExpandable = suggestion.type === 'repetition' && suggestion.details && Array.isArray(suggestion.details);

            // Container for main row
            const mainRow = item.createDiv({ cls: 'smartwrite-suggestion-main-row' });
            
            // Dot
            const dot = mainRow.createDiv({ cls: 'smartwrite-severity-dot' });
            const typeLower = suggestion.type.toLowerCase();
            if (typeLower === 'grammar') dot.addClass('smartwrite-severity-error');
            else if (typeLower === 'long-sentence' || typeLower === 'repetition') dot.addClass('smartwrite-severity-warning');
            else dot.addClass('smartwrite-severity-info');

            // Content
            const content = mainRow.createDiv({ cls: 'smartwrite-suggestion-content' });
            
            const typeHeader = content.createDiv({ cls: 'smartwrite-suggestion-header' });
            // Type
            const type = typeHeader.createSpan({ cls: 'smartwrite-suggestion-type' });
            type.setText(suggestion.type.charAt(0).toUpperCase() + suggestion.type.slice(1));
            
            // If expandable, add toggle icon
            if (isExpandable) {
                mainRow.classList.add('is-expandable');
                const toggleIcon = typeHeader.createSpan({ cls: 'smartwrite-suggestion-toggle-icon' });
                toggleIcon.setText('▼'); // Or chevron
                
                mainRow.addEventListener('click', () => {
                   item.classList.toggle('is-collapsed');
                });
                item.classList.add('is-collapsed'); // Default collapsed
            }

            // Message
            const description = content.createDiv({ cls: 'smartwrite-suggestion-description' });
            description.setText(suggestion.message);

            if (suggestion.explanation) {
                item.setAttribute('title', suggestion.explanation);
            }

            // Render Details if Repetition
            if (isExpandable) {
                const detailsContainer = item.createDiv({ cls: 'smartwrite-suggestion-details' });
                const reps = suggestion.details as Array<{word: string, count: number}>;
                
                // Details Grid or List
                reps.slice(0, 10).forEach(rep => { // Limit to 10
                    const repItem = detailsContainer.createDiv({ cls: 'smartwrite-repetition-item' });
                    repItem.createSpan({ cls: 'smartwrite-rep-word' }).setText(rep.word);
                    repItem.createSpan({ cls: 'smartwrite-rep-count' }).setText(String(rep.count));
                });
                if (reps.length > 10) {
                     detailsContainer.createDiv({ cls: 'smartwrite-rep-more' }).setText(`+${reps.length - 10} more`);
                }
            }
        }
    }

    public update(suggestions: SuggestionsResult | null): void {
        this.suggestions = suggestions;
        this.renderContent();
    }
}